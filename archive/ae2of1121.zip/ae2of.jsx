﻿#include "utils.jsx"
#include "lua_resource.jsx"
#include "effect_json.jsx"

//-------------------------------------------------------------------------------------- main -------------------------------------------
var path = app.project.file.fsName.toString().replace(".aep","") + "_of";
resetFolderIfNeed(path);
inputFiles = []
var transformProperties = ["position", "anchorPoint", "scale", "rotation", "xRotation", "yRotation", "opacity"]

for (var i = 1; i <= app.project.items.length; i++) {
    item = app.project.item(i)
    if (!(item instanceof CompItem) || item.numLayers <= 0) {
        continue
    }

    duration = item.duration
    frameRate = item.frameRate
    workAreaStart = item.workAreaStart
    workAreaDuration = item.workAreaDuration
    width = item.width
    height = item.height
    
    var layers = splitLayers(item)
    var maskLayers = layers[0]
    var maskAllLayers = layers[1]
    var backgroundLayers = layers[2]
    var otherLayers = layers[3]
    
    var filterJsons = []    
    
    // background
    if (backgroundLayers.length > 0) {
        var pathInfo = saveBackgroundVideo (width, height, workAreaStart, workAreaDuration, backgroundLayers, path)
    }

    // mask all layer
    if (maskAllLayers.length > 0) {
        var pathInfo = saveMaskAllVideo (width, height, workAreaStart, workAreaDuration, maskAllLayers, path)
    }
    // mask
    var maskVideoPathInfos = []
    if (maskLayers.valueOf() != undefined) {
        maskVideoPathInfos = saveMaskVideos (width, height, workAreaStart, workAreaDuration, maskLayers, path)
        for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
            var pathInfo = maskVideoPathInfos[filePathIndex]
        }
    }
    
    // other layers
    for (var layerIndex = 0; layerIndex < otherLayers.length; layerIndex++) {
        var layer = otherLayers[layerIndex]
        var keyTimes = getAllKeyTimesInLayer (layer, workAreaStart)
        var animations = getAnimationFromLayer(layer, keyTimes)
        var animationFileName = escape(layer.name.replace(/\s+/g,"_"));
        // find mask video index
        var maskVideoIndex = -1
        if (maskAllLayers.length > 0) {
            maskVideoIndex = (backgroundLayers.length > 0 ? 1 : 0)
        } else {
            for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
                var pathInfo = maskVideoPathInfos[filePathIndex]
                if (pathInfo.maskdName == layer.name) {
                    maskVideoIndex = (backgroundLayers.length > 0 ? 1 : 0)  + filePathIndex + 1
                    break
                }
            }
        }
    
        // filter
        var filterJSON = oneFilter(path, animationFileName, layer, maskVideoIndex)
        filterJsons.push (filterJSON)
        
        // animation
        saveAnimations(animations, path, animationFileName)
    }

    //ofeffect
    var f = new File(path + "/effect"+i.toString()+".ofeffect");
    f.open ("we", "TEXT", "");
    f.encoding = "UTF-8"
    f.write (effectHeader(filterJsons.length, duration))
    f.write (filterJsons.join (","))
    f.write(effectFooter())
    f.close();
}
var jsPath = new File($.fileName)
copyLuaResources(jsPath.path, path)
alert("导出成功："+path);

//-------------------------------------------------------------------------------------- function -------------------------------------------
function splitLayers(compItem) {
    if (!(compItem instanceof CompItem)) {
        return [{}, [], [], []]
    }
    var maskLayers = {}
    var maskAllLayers = []
    var backgroundLayers = []
    var otherLayers = []
    for (var layerIndex = 1; layerIndex <= compItem.numLayers; layerIndex++) {
        layer = compItem.layer(layerIndex)
        if (!layer.enabled || layer instanceof CameraLayer) {
            continue
        }
        if (isMaskLayer (layer)) {
            var maskLayersForALayer = maskLayers[getMaskdLayerName(layer)]
            if (maskLayersForALayer == undefined) {
                maskLayersForALayer = []
            }
            maskLayersForALayer.push (layer)
            maskLayers[getMaskdLayerName(layer)] = maskLayersForALayer
        } else if (isMaskAllLayer(layer)) {
            maskAllLayers.push (layer)
        }
        else if (isBackgroundLayer(layer)) {
            backgroundLayers.push (layer)
        } else {
            otherLayers.push (layer)
        }
    }
    return [maskLayers, maskAllLayers, backgroundLayers, otherLayers]
}
function isMaskLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_maskVideo") > 0
}
function isBackgroundLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name=="background"
}
function isMaskAllLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_maskAllVideo") > 0
}
function getMaskdLayerName(layer) {
    if (!isMaskLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_maskVideo"))
}
function getMaskAllLayerName(layer) {
    if (!isMaskAllLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_maskAllVideo"))
}
function getBackgroundLayerName(layer) {
    if (!isBackgroundLayer(layer)) {
        return ""
    }
    return "background"
}

function saveMaskVideos(width, height, beginTime, duration, maskLayers, basePath) {
    var videoPaths = []
    for (var maskdLayerName in maskLayers) {
        var maskLayersForALayer = maskLayers[maskdLayerName]
        var fileName = maskdLayerName
        var filePathInfo = saveVideoFromLayers (maskLayersForALayer, basePath + "/res", fileName)
        var filePath = filePathInfo.filePath
        var extension = filePathInfo.extension
        fileName = escape(fileName.replace(/\s+/g,"_"))
        var resName = "res/"+ fileName + "_mask." + extension
        renameFile (filePath, basePath + "/" + resName)
        inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
        videoPaths.push ({path:resName, fileName: fileName, maskdName: maskdLayerName})
    }
    return videoPaths
}

function saveBackgroundVideo(width, height, beginTime, duration, backgroundLayers, basePath) {
    var fileName = getBackgroundLayerName(backgroundLayers[0])
    var filePathInfo = saveVideoFromLayers (backgroundLayers, basePath + "/res", fileName)
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
    var resName = "res/"+ fileName + "." + extension
    inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    
    return {path:resName, fileName: fileName}
}
function saveMaskAllVideo(width, height, beginTime, duration, maskAllLayers, basePath) {
    var fileName = getMaskAllLayerName(maskAllLayers[0])
    var filePathInfo = saveVideoFromLayers (maskAllLayers, basePath + "/res", fileName)
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
    fileName = escape(fileName.replace(/\s+/g,"_"))
    var filePathComponents = filePath.split (".")
    var resName = "res/"+ fileName + "_maskall." + extension
    renameFile (filePath, basePath+ "/" + resName)
    inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    
    return {path:resName, fileName: fileName}
}

//---------------------------------------------------------------------- export layer --------------------------------------

function saveVideoFromLayers(layers, path, fileName) {
    var filePathWithFileName = path + "/" + fileName + ".avi"
    var path = exportLayers(layers, filePathWithFileName, -1)
    var mp4Path = path.replace (".avi", ".mp4")
    system.callSystem("ffmpeg -i \""+path+"\" -strict -2 -pix_fmt yuv420p \""+mp4Path + "\"")
    var aviFile = new File(path)
    if (aviFile.exists) {
        aviFile.remove()
    }
    return {filePath: mp4Path, extension:"mp4"}
}

function saveImageFromLayers(layers, path, fileName) {
    var containingComp = layer.containingComp
    var originDuration = containingComp.workAreaDuration
    containingComp.workAreaDuration = 0.04
    var filePathWithFileName = path + "/" + fileName + "[#####].png"
    exportLayers(layers, filePathWithFileName, 14)
    containingComp.workAreaDuration = originDuration
    
    var frameIndex = (containingComp.workAreaStart*containingComp.frameRate) .toString()
    var fullFrameIndex = ""
    for (var i = 0; i < (5-frameIndex.length); i++) {
        fullFrameIndex += "0"
    }
    fullFrameIndex += frameIndex
    var imageFile = new File(path + "/" + fileName + fullFrameIndex + ".png")
    var newName = path + "/" + fileName + ".png"
    imageFile.rename (newName)
    return newName
}

function exportLayers(layers, filePathWithFileName, usingTemplateIndex) {
    var containingComp = layer.containingComp
    var originLayerEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        alayer.enabled = false
    }
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var alayer = layers[layerIndex]
        alayer.enabled = true
    }
    var renderQueue = app.project.renderQueue
    renderQueue.items.add(containingComp)
    var renderItem = app.project.renderQueue.item(app.project.renderQueue.numItems)
    var outputModule = renderItem.outputModule(1)
    if (usingTemplateIndex >= 0) {
        outputModule.applyTemplate(outputModule.templates[usingTemplateIndex])
    }
    outputModule.file = new File(filePathWithFileName)
    renderQueue.render()
    renderItem.remove()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
    }
    return filePathWithFileName
}

//------------------------------------------------------------------------ utils ------------------------------------------
function resetFolderIfNeed(path) {
    if (app.project.file == undefined) {
        alert("请保存文件");
    }
    var folder = new Folder(path);
    if  (folder.exists) {
        var files = folder.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File) {
                files[i].remove()
            }
        }
        folder.remove ();
    }
    folder.create();
    
    var res = new Folder(path+"/res");
    if  (res.exists) {
        var files = res.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File) {
                files[i].remove()
            }
        }
        res .remove ();
    }
    res.create();
}
