﻿
function renameFile(filePath, newFilePath) {
    if (filePath == newFilePath) {
        return true
   }
    var file = new File (filePath)
    if (file.exists) {
        var oldFile = new File(newFilePath)
        oldFile.remove()
        file.rename(newFilePath)
        return true
    } else {
        return false
    }
}

function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16).toUpperCase();
    });
}