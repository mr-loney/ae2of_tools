﻿function copyLuaResources(srcPath, destPath) {
    var resources = ["locus.oflua", "music.oflua"]
    for (var resourceIndex = 0;  resourceIndex < resources.length; resourceIndex++) {
        var resource = resources[resourceIndex]
        var resourceFile = new File(srcPath + "/" + resource)
        resourceFile.copy (destPath + "/" + resource)
    }
}