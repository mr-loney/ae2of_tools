﻿#include "utils.jsx"
#include "lua_resource.jsx"
#include "effect_json.jsx"
#include "svga.jsx"

//-------------------------------------------------------------------------------------- main -------------------------------------------
var ExportType = {
    video: 3,
    svga: 1,
    other: -1,
}
var path = app.project.file.fsName.toString().replace(".aep","") + "_of";
resetFolderIfNeed(path);
inputFiles = []
uiinfo_music = []
uiinfo_video = []
var transformProperties = ["position", "anchorPoint", "scale", "rotation", "xRotation", "yRotation", "opacity"]

for (var i = 1; i <= app.project.items.length; i++) {
    item = app.project.item(i)
    if (!(item instanceof CompItem) || item.numLayers <= 0) {
        continue
    }

    duration = item.duration
    frameRate = item.frameRate
    workAreaStart = item.workAreaStart
    workAreaDuration = item.workAreaDuration
    width = item.width
    height = item.height
    inputFiles = []
    uiinfo_music = []
    uiinfo_video = []
    
    var layers = splitLayers(item)
    var maskLayers = layers[0]
    var maskAllLayers = layers[1]
    var backgroundLayers = layers[2]
    var svgaLayers = layers[3]
    var otherLayers = layers[4]
    
    var filterJsons = []    
    
    // background
    if (backgroundLayers.length > 0) {
        var pathInfo = saveBackgroundVideo (width, height, workAreaStart, workAreaDuration, backgroundLayers, path)
    }
    // mask all layer
    var maskAllPathInfo
    if (maskAllLayers.length > 0) {
        maskAllPathInfo = saveMaskAllVideo (width, height, workAreaStart, workAreaDuration, maskAllLayers, path)
    }
    // mask
    var maskVideoPathInfos = []
    if (Object.keys(maskLayers) != "") {
        maskVideoPathInfos = saveMaskVideos (width, height, workAreaStart, workAreaDuration, maskLayers, path)
        for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
            var pathInfo = maskVideoPathInfos[filePathIndex]
        }
    }
    
    // svga
    if (Object.keys(svgaLayers) != "") {
        var svgaPathInfos = saveSVGAs (width, height, workAreaStart, workAreaDuration, svgaLayers, path)
        for (var filePathIndex = 0; filePathIndex < svgaPathInfos.length; filePathIndex++) {
            var pathInfo = svgaPathInfos[filePathIndex]
            var mask = findMaskForLayer(layer, maskAllLayers.length > 0, backgroundLayers.length > 0, maskAllPathInfo, maskVideoPathInfos)
            var filterJSON = svgaFilter (workAreaStart, workAreaDuration, pathInfo.maskdName, width, height, pathInfo.path, mask.maskType, mask.maskRes)
            filterJsons.push (filterJSON)
        }
    }
    // other layers
    for (var layerIndex = 0; layerIndex < otherLayers.length; layerIndex++) {
        var layer = otherLayers[layerIndex]
        var keyTimes = getAllKeyTimesInLayer (layer, workAreaStart)
        var animations = getAnimationFromLayer(layer, keyTimes)
        var animationFileName = nameWithRight(layer.name);
        // find mask video index

        var mask = findMaskForLayer(layer, maskAllLayers.length > 0, backgroundLayers.length > 0,  maskAllPathInfo, maskVideoPathInfos)
        
        // filter
        var filterJSON = oneFilter(path, animationFileName, layer, mask.maskType, mask.maskRes)
        filterJsons.push (filterJSON)
        
        // animation
        saveAnimations(animations, path, animationFileName)
    }

    //ofeffect
    var f = new File(path + "/effect"+i.toString()+".ofeffect");
    f.open ("we", "TEXT", "");
    f.encoding = "UTF-8"
    f.write (effectHeader(filterJsons.length, duration))
    f.write (filterJsons.join (","))
    f.write(effectFooter())
    f.close();
}
var f = new File(path + "/uiinfo.conf");
f.open ("we", "TEXT", "");
f.encoding = "UTF-8"
f.write (uiinfo())
f.close();
copyLuaResources(path)
alert("导出成功："+path);

//-------------------------------------------------------------------------------------- function -------------------------------------------
function findMaskForLayer(layer, hasMaskAll, hasBackground, maskAllPathInfo, maskVideoPathInfos) {
    var maskRes = "0"
    var maskType = ExportType.video
    if (hasMaskAll) { 
        maskType = maskAllPathInfo.resType
        if (maskAllPathInfo.resType == ExportType.svga) {
            maskRes = maskAllPathInfo.path
        } else {
            maskRes = (hasBackground ? 1 : 0) + 1
        }   
    } else {
        for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
            var pathInfo = maskVideoPathInfos[filePathIndex]
            if (pathInfo.maskdName == layer.name) {
                maskType = pathInfo.resType
                if (maskType == ExportType.svga) {
                    maskRes = pathInfo.path
                } else {
                    maskRes = (hasBackground ? 1 : 0) + filePathIndex + 1
                }
                break
            }
        }
    }
    return {maskType: maskType, maskRes: maskRes}
}
function splitLayers(compItem) {
    if (!(compItem instanceof CompItem)) {
        return [{}, [], [], {}, []]
    }
    var maskLayers = {}
    var maskAllLayers = []
    var backgroundLayers = []
    var svgaLayers = {}
    var otherLayers = []
    for (var layerIndex = 1; layerIndex <= compItem.numLayers; layerIndex++) {
        var layer = compItem.layer(layerIndex)
        if (!layer.enabled || layer instanceof CameraLayer) {
            continue
        }
        if (isMaskLayer (layer)) {
            var maskLayersForALayer = maskLayers[getMaskdLayerName(layer)]
            if (maskLayersForALayer == undefined) {
                maskLayersForALayer = []
            }
            maskLayersForALayer.push (layer)
            maskLayers[getMaskdLayerName(layer)] = maskLayersForALayer
        } else if (isMaskAllLayer(layer)) {
            maskAllLayers.push (layer)
        }
        else if (isBackgroundLayer(layer)) {
            backgroundLayers.push (layer)
        } else if (isSVGALayer(layer)) {
            var svgaForLayers = svgaLayers[getOriginName(layer)]
            if (svgaForLayers == undefined) {
                svgaForLayers = []
            }
            svgaForLayers.push (layer)
            svgaLayers[getOriginName(layer)] = svgaForLayers
        } else {
            otherLayers.push (layer)
        }
    }
    return [maskLayers, maskAllLayers, backgroundLayers, svgaLayers, otherLayers]
}
function isMaskLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_mask") > 0 && !isMaskAllLayer(layer)
}
function isBackgroundLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name=="background"
}
function isMaskAllLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("maskall") != -1
}
function isSVGALayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.split ("_").pop().indexOf ("SVGA") != -1
}
function getMaskdLayerName(layer) {
    if (!isMaskLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_mask"))
}
function getMaskdAllLayerName(layer) {
    if (!isMaskAllLayer(layer)) {
        return ""
    }
    return "maskall"
}

function getOriginName(layer) {
    var nameComponents = layer.name.split ("_")
    nameComponents.pop()
    return nameComponents.join ("_")
}
function getBackgroundLayerName(layer) {
    if (!isBackgroundLayer(layer)) {
        return ""
    }
    
    return "background"
}
function getExportType(layer) {
    var exportType = layer.name.split ("_").pop()
    if (exportType.indexOf ("Video") != -1) {
        return ExportType.video
    } else if (exportType.indexOf ("SVGA") != -1) {
        return ExportType.svga
    } else if (isBackgroundLayer (layer) || isMaskAllLayer (layer)) {
        return ExportType.video
    } else {
        return ExportType.other
    }
}
function saveMaskVideos(width, height, beginTime, duration, maskLayers, basePath) {
    var videoPaths = []
    for (var maskdLayerName in maskLayers) {
        var maskLayersForALayer = maskLayers[maskdLayerName]
        var fileName = maskdLayerName
        var filePathInfo
        if (getExportType(maskLayersForALayer[0]) == ExportType.video) {
            filePathInfo = saveVideoFromLayers (maskLayersForALayer, basePath + "/res", fileName,true)
        } else if (getExportType(maskLayersForALayer[0]) == ExportType.svga) {
            filePathInfo = saveSVGAFromLayers (maskLayersForALayer, basePath + "/res", fileName)
        }
        var filePath = filePathInfo.filePath
        var extension = filePathInfo.extension
        var newFileName = nameWithRight(fileName)
        var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length).replace (fileName + "." + extension, newFileName + "_mask." + extension)
//~         var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length).replace (fileName, newFileName + "_mask")
        renameFile (filePath, basePath + "/" + resName)
        if (getExportType(maskLayersForALayer[0]) == ExportType.video) {
            inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
        }
        uiinfo_video.push ("{\"beginTime\":\""+(parseInt((beginTime*1000))).toString()+"\",\"endTime\":\""+(parseInt((beginTime+duration)*1000)).toString()+"\",\"filePath\":\""+resName+"\"}")
        videoPaths.push ({path:resName, fileName: fileName, maskdName: maskdLayerName, resType: getExportType(maskLayersForALayer[0])})
    }
    return videoPaths
}
function saveSVGAs(width, height, beginTime, duration, svgaLayers, basePath) {
    var svgaPaths = []
    for (var maskdLayerName in svgaLayers) {
        var maskLayersForALayer = svgaLayers[maskdLayerName]
        var fileName = maskdLayerName
        var filePathInfo = saveSVGAFromLayers (maskLayersForALayer, basePath + "/res", fileName)
        var filePath = filePathInfo.filePath
        var extension = filePathInfo.extension
        fileName = nameWithRight(fileName)
        var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length)
//~         renameFile (filePath, basePath + "/" + resName)
//~         uiinfo_video.push ("{\"beginTime\":\""+(parseInt((beginTime*1000))).toString()+"\",\"endTime\":\""+(parseInt((beginTime+duration)*1000)).toString()+"\",\"filePath\":\""+resName+"\"}")
        svgaPaths.push ({path:resName, fileName: fileName, maskdName: maskdLayerName, layers: maskLayersForALayer})
    }
    return svgaPaths
}
function saveBackgroundVideo(width, height, beginTime, duration, backgroundLayers, basePath) {
    var fileName = getBackgroundLayerName(backgroundLayers[0])
    var filePathInfo
    if (getExportType(backgroundLayers[0]) == ExportType.video) {
        filePathInfo = saveVideoFromLayers (backgroundLayers, basePath + "/res", fileName,false)
    } else if (getExportType(backgroundLayers[0]) == ExportType.svga) {
        filePathInfo = saveSVGAFromLayers (backgroundLayers, basePath + "/res", fileName)
    }
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
    var newFileName = nameWithRight(backgroundLayers[0].containingComp.name) + "_background"
    var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length).replace (fileName + "." + extension, newFileName + "." + extension)
    renameFile (filePath, basePath+ "/" + resName)
    if (getExportType(backgroundLayers[0]) == ExportType.video) {
        inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    }
    uiinfo_video.push ("{\"beginTime\":\""+(parseInt((beginTime*1000))).toString()+"\",\"endTime\":\""+(parseInt((beginTime+duration)*1000)).toString()+"\",\"filePath\":\""+resName+"\"}")
        
    return {path:resName, fileName: fileName, resType: getExportType(backgroundLayers[0])}
}
function saveMaskAllVideo(width, height, beginTime, duration, maskAllLayers, basePath) {
    var fileName = getMaskdAllLayerName(maskAllLayers[0])
    var filePathInfo
    if (getExportType(maskAllLayers[0]) == ExportType.video) {
        filePathInfo = saveVideoFromLayers (maskAllLayers, basePath + "/res", fileName,true)
    } else if (getExportType(maskAllLayers[0]) == ExportType.svga) {
        filePathInfo = saveSVGAFromLayers (maskAllLayers, basePath + "/res", fileName)
    }
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
    var newFileName = nameWithRight(maskAllLayers[0].containingComp.name) + "_maskall"
    var filePathComponents = filePath.split (".")
    var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length).replace (fileName + "." + extension, newFileName + "." + extension)
    renameFile (filePath, basePath+ "/" + resName)
    if (getExportType(maskAllLayers[0]) == ExportType.video) {
        inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    }
    uiinfo_video.push ("{\"beginTime\":\""+(parseInt((beginTime*1000))).toString()+"\",\"endTime\":\""+(parseInt((beginTime+duration)*1000)).toString()+"\",\"filePath\":\""+resName+"\"}")
    
    return {path:resName, fileName: fileName, resType: getExportType(maskAllLayers[0])}
}

//---------------------------------------------------------------------- export layer --------------------------------------

function saveSVGAFromLayers(layers, path, fileName) {
    if (layers.length == 0) {
        return ""
    }
    var containingComp = layers[0].containingComp
    var originLayerEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        alayer.enabled = false
    }
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var alayer = layers[layerIndex]
        alayer.enabled = true
    }
    var svgaResourceFolderPath = path + "/" + fileName + "_svga"
    var resourceDiretoryPath = startConvert(svgaResourceFolderPath)
    var svgaFilePath = path + "/" + fileName + ".svga"
    zipFolder (resourceDiretoryPath, svgaFilePath)
    removeFolder (resourceDiretoryPath)
    
    var a2mFilePath = svgaToY2A (svgaFilePath, svgaFilePath.replace (".svga", ".y2a"))

//~     var specFilePath = svgaResourceFolderPath + "/movie.spec"
    
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
    }
    return {filePath: a2mFilePath, extension:"a2m"}
}

function saveVideoFromLayers(layers, path, fileName,allIFrame) {
    var mp4Path
    if (layers.length == 1 && layers[0].source != undefined && layers[0].source.file != null) {
        var f = layers[0].source.file.displayName.substr (0, layers[0].source.file.displayName.indexOf ("."))
        var extension = layers[0].source.file.displayName.replace(f,"")
        var copyPath =  path + "/" +  fileName+""+extension;
        layers[0].source.file.copy (copyPath)
        
        if (extension == ".mp4") {
            mp4Path = copyPath
            var tmpPath = path + "/" +  fileName+"_new"+extension;
            transformVideoWithFFMPEG(copyPath, tmpPath, layers[0].containingComp.width, layers[0].containingComp.height,allIFrame)
            var oldFile = new File(mp4Path)
            if (oldFile.exists) {
                oldFile.remove()
            }
            var newFile = new File(tmpPath)
            newFile.rename(mp4Path)
        } else if (extension == ".avi"){
            mp4Path = copyPath.replace (".avi", ".mp4")
            transformVideoWithFFMPEG(copyPath, mp4Path, layers[0].containingComp.width, layers[0].containingComp.height,allIFrame)
            var aviFile = new File(path)
            if (aviFile.exists) {
                aviFile.remove()
            }
        }
    } else {
        //create new video
        var filePathWithFileName = path + "/" + fileName + ".avi"
        var path = exportLayers(layers, filePathWithFileName, -1)
        mp4Path = path.replace (".avi", ".mp4")
        transformVideoWithFFMPEG(path, mp4Path, -1, -1,allIFrame)
        var aviFile = new File(path)
        if (aviFile.exists) {
            aviFile.remove()
        }
    }
    return {filePath: mp4Path, extension:"mp4"}
}

function transformVideoWithFFMPEG(from, to, w, h, allIFrame) {
    var args = "-c:v libx264 -preset medium -x264-params crf=23:bframes=0 -strict -2 -pix_fmt yuv420p -b:v 1000k"
    if (w > 0 && h > 0) {
        args += " -s "+w+"x"+h
    }
    if (allIFrame) {
        args += " -g 1 "
    }
    system.callSystem("ffmpeg -i \""+from+"\" "+args+" \""+to + "\"")
}

function saveImageFromLayers(layers, path, fileName) {
    var containingComp = layer.containingComp
    var originDuration = containingComp.workAreaDuration
    containingComp.workAreaDuration = containingComp.frameDuration
    var filePathWithFileName = path + "/" + fileName + "[#####].png"
    exportLayers(layers, filePathWithFileName, 14)
    containingComp.workAreaDuration = originDuration
    
    var frameIndex = (containingComp.workAreaStart*containingComp.frameRate) .toString()
    var fullFrameIndex = ""
    for (var i = 0; i < (5-frameIndex.length); i++) {
        fullFrameIndex += "0"
    }
    fullFrameIndex += frameIndex
    var imageFile = new File(path + "/" + fileName + fullFrameIndex + ".png")
    var newName = path + "/" + fileName + ".png"
    imageFile.rename (newName)
    return newName
}

function exportLayers(layers, filePathWithFileName, usingTemplateIndex) {
    if (layers.length == 0) {
        return ""
    }
    var containingComp = layers[0].containingComp
    var originLayerEnabled = new Object()
    var originLayerAudioEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        originLayerAudioEnabled[layerIndex] = alayer.audioEnabled
        if (layers.contains(alayer)) {
            alayer.enabled = true
        } else {
            alayer.enabled = false
            alayer.audioEnabled = false
        }
    }
    var renderQueue = app.project.renderQueue
    renderQueue.items.add(containingComp)
    var renderItem = app.project.renderQueue.item(app.project.renderQueue.numItems)
    var outputModule = renderItem.outputModule(1)
    if (usingTemplateIndex >= 0) {
        outputModule.applyTemplate(outputModule.templates[usingTemplateIndex])
    }
    outputModule.file = new File(filePathWithFileName)
    renderQueue.render()
    renderItem.remove()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
        alayer.audioEnabled = originLayerAudioEnabled[layerIndex]
    }
    return filePathWithFileName
}

//------------------------------------------------------------------------ Filter ------------------------------------------
function svgaToY2A(svgaFilePath, y2aFilePath) {
    var y2aToolPSPath = platformSpecificPath(rootDirectory() + "/Y2ATool/Y2ATool.exe")
    var svgaPSPath = platformSpecificPath(svgaFilePath)
    var y2aPSPath = platformSpecificPath(y2aFilePath)
    system.callSystem("\"" + y2aToolPSPath + "\" --y2aExOptimalEfficiency " + "\"" +svgaPSPath + "\" \"" + y2aPSPath + "\" png \"pingo -s9\"")
//~     system.callSystem("\"" + y2aToolPSPath + "\" --y2aExCheetah " + "\"" +svgaPSPath + "\" \"" + y2aPSPath + "\" png \"pingo -s9\"")
    var folderFilePath = y2aPSPath.replace (".y2a", "_y2a")
    var a2mFilePath
    unzipFile(y2aPSPath, folderFilePath)
    var folder = new Folder(folderFilePath)
    if  (folder.exists) {
        var files = folder.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File && files[i].fsName.indexOf (".a2m")) {
                a2mFilePath = files[i].fsName
                break
            }
        }
    }
    removeFile (svgaPSPath)
    removeFile (y2aPSPath)
    return independantPath(a2mFilePath)
}
function svgaFilter(startTime, duration, description, width, height, svgaPath, maskType, maskRes) {
    return "{"+
                    "\"beginTime\":"+(startTime<0 ? 0 : startTime).toString()+","+
                    "\"endTime\":"+(parseInt((startTime+duration)*1000)).toString()+","+
                    "\"type\":\"CustomLuaFilter\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(duration*1000)).toString()+","+
                    "\"description\":\""+description +"\","+
                    "\"paramf\":{"+
                                        "\"Width\":"+width.toString()+","+
                                        "\"Height\":"+height.toString()+","+
                                        "\"ScaleX\": 1.0,"+
                                        "\"ScaleY\": 1.0,"+
                                        "\"TranslateX\": 0.0,"+
                                        "\"TranslateY\": 0.0,"+
                                        "\"RotateX\": 0.0,"+
                                        "\"RotateY\": 0.0,"+
                                        "\"RotateZ\": 0.0,"+
                                        "\"Alpha\": 1.0,"+
                                        "\"BlurRadius\": 0.0,"+
                                        "\"BlurWidthOffset\": 1.0,"+
                                        "\"BlurHeightOffset\": 1.0,"+
                                        "\"MaskScaleX\": 1.0,"+
                                        "\"MaskScaleY\": 1.0,"+
                                        "\"MaskTranslateX\": 0.0,"+
                                        "\"MaskTranslateY\": 0.0,"+
                                        "\"MaskRotateX\": 0.0,"+
                                        "\"MaskRotateY\": 0.0,"+
                                        "\"MaskRotateZ\": 0.0,"+
                                        "\"MaskAlpha\": 1.0"+
                                        "},"+
                    "\"parami\":{"+
                                        "\"VideoIndex\":0,"+
                                        "\"RenderType\":4,"+
                                        "\"FontSize\":0,"+
                                        "\"BlendMode\":0,"+
                                        "\"MaskRenderType\":" + maskType.toString() + ", "+
                                        "\"MaskVideoIndex\":" + (maskType == ExportType.video ? maskRes : "0") + 
                                        "},"+
                    "\"parambool\":{\"FontBold\":false,\"FontShadow\":false,\"AnimationDataChanged\":true},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":8,\"resName\":\""+svgaPath+"\"},"+
                                            "\"Music\":{\"resType\":8,\"resName\":\""+svgaPath+"\"},"+
                                            "\"MaskTexture\":{\"resType\":" + maskType.toString() + ",\"resName\":\"" + maskRes + "\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\"\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":[1,1,1,1]},"+
                    "\"paramstring\":{\"RenderText\":\"\",\"Font\":\"\"},"+
                    "\"ext_data\":{\"luaScriptName\":\"locus.oflua\"}"+
                    "}";
}