﻿
function copyResources(srcPath, destPath) {
    var resources = ["locus.oflua", "music.oflua"]
    for (var resourceIndex = 0;  resourceIndex < resources.length; resourceIndex++) {
        var resource = resources[resourceIndex]
        var resourceFile = new File(srcPath + "/" + resource)
        resourceFile.copy (destPath + "/" + resource)
    }
}
function rootDirectory() {
    var thisScriptFile = new File($.fileName)
    return thisScriptFile.parent.toString()
}
function removeFolder(folderPath) {
    var folder = new Folder(folderPath)
    if (!folder.exists) {
        return
    }
    var files = folder.getFiles ()
    for (var i in files) {
        if (files[i] instanceof File) {
            files[i].remove()
        }
    }
    folder.remove ()
}
function removeFile(filePath) {
    var file = new File(filePath)
    if (! file.exists) {
        return
    }
     file.remove ()
}
function resetFolderIfNeed(path) {
    if (app.project.file == undefined) {
        alert("请保存文件");
    }
    removeFolder (path)
    var folder = new Folder(path)
    folder.create();
    
    var res = new Folder(path+"/res");
    if  (res.exists) {
        var files = res.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File) {
                files[i].remove()
            }
        }
        res .remove ();
    }
    res.create();
}

function zipFolder(folderPath, zipFileName) {
    var zipCommandFilePath = platformSpecificPath(rootDirectory() + "/zip.exe")
    system.callSystem("\"" + zipCommandFilePath + "\" -r -j  \""+zipFileName+"\" \""+ folderPath+ "\"")
}
function unzipFile(filePath, folderPath) {
    var unzipCommandFilePath = platformSpecificPath(rootDirectory() + "/unzip.exe")
    system.callSystem("\"" + unzipCommandFilePath + "\" \""+filePath+"\" -d \""+ folderPath+ "\"")
}
function platformSpecificPath(path) {
    var file = new File(path)
    return file.fsName
}

function independantPath(psPath) {
    var file = new File(psPath)
    return file.fullName
}

function renameFile(filePath, newFilePath) {
    if (filePath == newFilePath) {
        return true
   }
    var file = new File (filePath)
    if (file.exists) {
        var oldFile = new File(newFilePath)
        oldFile.remove()
        file.rename(newFilePath)
        return true
    } else {
        return false
    }
}

function nameWithRight(n) {
    return escape(n.replace(/\s+/g,"_")).replace(/%+/g,"")
}

function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16).toUpperCase();
    });
}

Array.prototype.contains = function (element) {
    if (this.length == 0 || element == undefined || element == null) {
        return false
    }
    for (var index = 0; index < this.length; index++) {
        if (this[index] === element) {
            return true
        }
    }
    return false
} 