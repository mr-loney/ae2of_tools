﻿function copyLuaResources(destPath) {
    var jsPath = new File($.fileName)
    var srcPath = jsPath.path

    var resources = ["locus.oflua", "music.oflua"]
    for (var resourceIndex = 0;  resourceIndex < resources.length; resourceIndex++) {
        var resource = resources[resourceIndex]
        var resourceFile = new File(srcPath + "/" + resource)
        resourceFile.copy (destPath + "/" + resource)
    }
}

function resourceFromWeb() {
    getAssets(function(config){
        alert(config)
    });
}

function getAssets(callback){
    var request = new XMLHttpRequest();
    var timeout = false;
    var timer = setTimeout( function(){
        timeout = true;
        request.abort();
    }, 10 );
    request.open( "GET", "http://ovotest.yy.com/asset/common?channel=3fd0c8b91d&version=1.0.0&os=1" );
    request.onreadystatechange = function(){
        if( request.readyState !== 4 ) return;
        if( timeout ) return;
        clearTimeout( timer );
        if( request.status === 200 ){
            callback( request.responseText );
        }
    }
    request.send( null );
}