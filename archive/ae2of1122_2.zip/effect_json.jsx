﻿


function effectHeader(filterCount, duration, layer) {
    var inputFilesCount = inputFiles.length
    var inputJson = "";
    for (var ii = 0; ii < inputFiles.length; ii++) {
        inputJson += inputFiles[ii] + ","
    }
    if (inputJson.length > 0) {
        inputJson = inputJson.substr(0,inputJson.length-1)
    }
    return "{\"ofversion\":\"4.0\",\"audioName\":\"\",\"duration\":"+(parseInt(duration*1000)).toString()+",\"playMode\":0,\"isFadeout\":false,\"fadeoutStart\":0,\"trackDataCacheTime\":0,"+
        "\"input_count\":"+inputFilesCount.toString()+",\"input_list\":["+inputJson+"],"+
        "\"effect_paramf_count\":0,\"effect_paramf_list\":[],"+
        "\"filter_count\":"+filterCount.toString()+",\"filter_list\":[";
}
function effectFooter() {
    return "],"+
        "\"animator_count\":0,\"animator_list\":[],\"scene_count\":0,\"scene_list\":[]}";
}
function oneFilter(path, animationKey, layer, maskVideoIndex) {
    var renderType = 1
    var resType = 1
    var resName= ""
    var textFontSize = 10
    var textFont = ""
    var text = ""
    var textColor = 1.0
    var textColor1 = 1.0
    var textColor2 = 1.0
    var textBlod = "false"
    var textShadow = "false"
    var oflua = "locus.oflua"
    var videoIndex = 1
    if (isMaskLayer (layer) || isBackgroundLayer (layer)) {
        return
//~     } else if () {
//~         renderType = 3
//~         resType = 4096
//~         
//~         var outputedFile = path + "/res/" +layer.name + ".avi"
//~         saveVideoFromLayers(maskLayers[layer.name], path + "/res", layer.name)
//~          var outputFile = new File (outputedFile)
//~         if (outputFile.exists) {
//~             var oldFile = new File(path + "/res/"+animationKey+".avi")
//~             oldFile.remove()
//~             outputFile.rename(path + "/res/"+animationKey+".avi")
//~             resName = "res/"+animationKey+".avi"
//~             inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
//~         }
    } else if (layer instanceof ShapeLayer) { 
        renderType = 1
        resType = 1
        
        var outputedShapeFile = path + "/res/"+layer.name+".png"
        saveImageFromLayers([layer], path + "/res" , layer.name)
        var outputFile = new File (outputedShapeFile)
        if (outputFile.exists) {
            var oldFile = new File(path + "/res/" + animationKey + ".png")
            oldFile.remove()
            outputFile.rename (path + "/res/" + animationKey + ".png")
    
            resName = "res/" + animationKey + ".png"
        } else {
            alert("形状图层生成位图失败")
        }
    } else if (layer instanceof TextLayer) { 
        renderType = 6
        text = layer.sourceText.value.text.replace(/[\r\n]/g, "") 
        textFontSize = layer.sourceText.value.fontSize
        textFont = layer.sourceText.value.fontFamily
        textFontLocation = layer.sourceText.value.fontLocation
        if (textFontLocation.length > 0) {
            var ttf = new File(textFontLocation)
            if (ttf.exists) {
                var copyPath = path + "/res/" + textFont + ".ttf"
                ttf.copy (copyPath)
            }
            textFont = "/res/" + textFont + ".ttf"
        }
        textColor = layer.sourceText.value.fillColor[0]
        textColor1 = layer.sourceText.value.fillColor[1]
        textColor2 = layer.sourceText.value.fillColor[2]
        if (layer.sourceText.value.fontStyle.value == "Blod") {
            textBlod = "true";
        }
    } else {
       if (layer.source != undefined && layer.source.file != null) {
            var  fileName = layer.source.file.displayName
            //copy File
            var ofPath = "res/" +  escape(fileName.replace(/\s+/g,"_"));
            var copyPath = path + "/" + ofPath
            layer.source.file.copy (copyPath)
            resName = ofPath
            
            if (fileName.indexOf(".mp3")>0 || fileName.indexOf(".wav")>0) {
                //音频
                renderType = 3
                resType = 64
                oflua  = "music.oflua"
                workAreaStart = layer.startTime
                workAreaDuration = layer.time
            } else if (fileName.indexOf(".png")>0 || fileName.indexOf(".jpg")>0) {
                //图片
                renderType = 1
                resType = 1
            } else if (fileName.indexOf(".mp4")>0 || fileName.indexOf(".avi")>0) {
                //视频
                renderType = 3
                resType = 4096
                inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
                videoIndex = inputFiles.length
            } else {
                type = 1
            }
        }
    }
    var workAreaStart = layer.inPoint
    var workAreaDuration = layer.outPoint - layer.inPoint
    var beginTime = parseInt(workAreaStart*1000)
    return "{"+
                    "\"beginTime\":"+(beginTime<0 ? 0 : beginTime).toString()+","+
                    "\"endTime\":"+(parseInt((workAreaStart+workAreaDuration)*1000)).toString()+","+
                    "\"type\":\"CustomLuaFilter\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(workAreaDuration*1000)).toString()+","+
                    "\"description\":\""+layer.name +"\","+
                    "\"paramf\":{"+
                                        "\"Width\":"+layer.width.toString()+","+
                                        "\"Height\":"+layer.height.toString()+","+
                                        "\"ScaleX\": 1.0,"+
                                        "\"ScaleY\": 1.0,"+
                                        "\"TranslateX\": 0.0,"+
                                        "\"TranslateY\": 0.0,"+
                                        "\"RotateX\": 0.0,"+
                                        "\"RotateY\": 0.0,"+
                                        "\"RotateZ\": 0.0,"+
                                        "\"Alpha\": 1.0,"+
                                        "\"BlurRadius\": 0.0,"+
                                        "\"BlurWidthOffset\": 1.0,"+
                                        "\"BlurHeightOffset\": 1.0,"+
                                        "\"MaskScaleX\": 1.0,"+
                                        "\"MaskScaleY\": 1.0,"+
                                        "\"MaskTranslateX\": 0.0,"+
                                        "\"MaskTranslateY\": 0.0,"+
                                        "\"MaskRotateX\": 0.0,"+
                                        "\"MaskRotateY\": 0.0,"+
                                        "\"MaskRotateZ\": 0.0,"+
                                        "\"MaskAlpha\": 1.0"+
                                        "},"+
                    "\"parami\":{"+
                                        "\"VideoIndex\":"+videoIndex.toString()+","+
                                        "\"RenderType\":"+renderType.toString()+","+
                                        "\"FontSize\":"+textFontSize.toString()+","+
                                        "\"BlendMode\":0,"+
                                        "\"MaskRenderType\":3, "+
                                        "\"MaskVideoIndex\":" + maskVideoIndex + 
                                        "},"+
                    "\"parambool\":{\"FontBold\":"+textBlod+",\"FontShadow\":"+textShadow+",\"AnimationDataChanged\":true},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"Music\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"MaskTexture\":{\"resType\":1,\"resName\":\"\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\"res/"+animationKey.toString()+".ofanim\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":["+textColor.toString()+","+textColor1.toString()+","+textColor2.toString()+",1]},"+
                    "\"paramstring\":{\"RenderText\":\""+text+"\",\"Font\":\""+textFont+"\"},"+
                    "\"ext_data\":{\"luaScriptName\":\""+oflua+"\"}"+
                "}";
}


//------------------------------------------------------------------------ animations ------------------------------------------
function valueAtTime(layer, propertyName, time) {
    if (time < 0) { 
        return undefined
    }
    if (!layer.transform.hasOwnProperty (propertyName) || layer.transform[propertyName] == null) {
        return undefined
    }
    property = layer.transform[propertyName]
    return property.valueAtTime(time, false)
}
function saveAnimations(animations, basePath, fileName) {
    var animationFile = new File(basePath + "/res/"+fileName+".ofanim");
    animationFile.open ("we", "", "")
    var animationJson = animationHeader(animations)
    var animationList = []
    for (var kk = 0; kk < animations.length; kk++) {
        animationList.push(oneAnimation (animations[kk]))
    }
    animationJson += animationList.join (",")
    animationJson += animationFooter();
    animationFile.write(animationJson)
    animationFile.close();
}
function getAllKeyTimesInLayer(layer, workAreaStart) {
    if (layer == null || !layer.enabled) {
        return []
    }
    var keyTimes = []
    for (var k = 0; k < transformProperties.length; k++) {
        if (layer.transform.hasOwnProperty (transformProperties[k])) {
            transformProperty = layer.transform[transformProperties[k]]
            propertyValue = transformProperty.value
            for (var l = 1; l <= transformProperty.numKeys; l++) {
                keyTime = transformProperty.keyTime(l)
                var duplicated = false
                for (var timeIndex in keyTimes) {
                    if (keyTimes[timeIndex] == keyTime) {
                        duplicated = true
                        break
                    }
                }
                if (!duplicated && keyTime >= 0 && keyTime >= workAreaStart && keyTime <= (workAreaStart + workAreaDuration)) { 
                    keyTimes.push(keyTime);
                }
            }
        }
    }

    function sortKeyTime(a, b) {
        if (a > b) return 1
        else if (a < b) return -1
        else return 0
    }
    keyTimes.sort(sortKeyTime)
    if (keyTimes.length > 0) {
        if (keyTimes[0]>workAreaStart) {
            var tmp = keyTimes.reverse()
            tmp.push(workAreaStart)
            keyTimes = tmp.reverse()
        }
    } else {
        keyTimes.push(workAreaStart)
    }
    return keyTimes
}
function getAnimationFromLayer(layer, keyTimes) {
    if (keyTimes.length <= 0) {
        return []
    }
    var animations = []
    for (var keyTimeIndex = 0; keyTimeIndex < keyTimes.length; keyTimeIndex++) {
        var animation = []
        var keyTime = keyTimes[keyTimeIndex]
        animation["keyTime"] = keyTime
        for (var propertyIndex = 0; propertyIndex < transformProperties.length; propertyIndex++) {
            propertyName = transformProperties[propertyIndex]
            value = valueAtTime (layer, propertyName, keyTime)
            if (value == undefined) {
                continue
            }
            animation[propertyName] = value
        }
        animations.push(animation)
    }
    var width = layer.width
    var height = layer.height
    if (layer instanceof TextLayer) {
        var sourceRect = layer.sourceRectAtTime(keyTimes[0], true)
        width = 0
        height = 0
    }
    for (var i = 0; i < animations.length ; i++) {
            var aeX = animations[i]["position"][0] - (animations[i]["anchorPoint"][0] - width/2.0)
            var aeY = animations[i]["position"][1] - (animations[i]["anchorPoint"][1] - height/2.0)
            animations[i]["translateX"] = aeX - layer.containingComp.width/2.0
            animations[i]["translateY"] = aeY - layer.containingComp.height/2.0
    }

    return animations
}
function animationHeader(animate) {
    var smoothMode = 2
    var maxInterval = 0
    for (var i = 1 ; i < animate.length ; i++) { //忽略第0帧
       if (i>2) {
           var interval = animate[i].keyTime - animate[i-1].keyTime
           if (interval > maxInterval) {
               maxInterval = interval
           }
       }
    }
    if (maxInterval > 0.2) {
        smoothMode = 0;
    }
    return "{\"version\":1,\"smoothMode\":"+smoothMode.toString()+",\"keyCount\":"+animate.length.toString()+",\"keys\":[";
}
function animationFooter() {
    return "]}";
}
function oneAnimation(animate) {
    return "{"+
                    "\"time\":"+animate.keyTime.toString()+","+
                    "\"translateX\":"+animate.translateX.toString()+","+
                    "\"translateY\":"+animate.translateY.toString()+","+
                    "\"scaleX\":"+(animate.scale[0]/100.0).toString()+","+
                    "\"scaleY\":"+(animate.scale[1]/100.0).toString()+","+
                    "\"rotateX\":"+(animate.rotation != undefined ? animate.rotation.toString() : "0")+","+
                    "\"rotateY\":0,"+
                    "\"rotateZ\":0,"+
                    "\"alpha\":"+(animate.opacity/100.0).toString()+","+
                    "\"maskTranslateX\":0,"+
                    "\"maskTranslateY\":0,"+
                    "\"maskScaleX\":1,"+
                    "\"maskScaleY\":1,"+
                    "\"maskRotateX\":0,"+
                    "\"maskRotateY\":0,"+
                    "\"maskRotateZ\":0,"+
                    "\"maskAlpha\":1,"+
                    "\"blurRadius\":0,"+
                    "\"blurWidthOffset\":0,"+
                    "\"blurHeightOffset\":0"+
                "}";
}