﻿//-------------------------------------------------------------------------------------- main -------------------------------------------

var path = app.project.file.fsName.toString().replace(".aep","") + "_of";
resetFolderIfNeed(path);
inputFiles = []
var transformProperties = ["position", "anchorPoint", "scale", "rotation", "xRotation", "yRotation", "opacity"]

for (var i = 1; i <= app.project.items.length; i++) {
    item = app.project.item(i)
    if (!(item instanceof CompItem) || item.numLayers <= 0) {
        continue
    }

    duration = item.duration
    frameRate = item.frameRate
    workAreaStart = item.workAreaStart
    workAreaDuration = item.workAreaDuration
    width = item.width
    height = item.height
    
    var splitLayers = splitLayers(item)
    var maskLayers = splitLayers[0]
    var maskAllLayers = splitLayers[1]
    var backgroundLayers = splitLayers[2]
    var otherLayers = splitLayers[3]
    
    var filterJsons = []    
    
    // background
    if (backgroundLayers.length > 0) {
        var pathInfo = saveBackgroundVideo (width, height, workAreaStart, workAreaDuration, backgroundLayers, path)
//~         var filterJSON = OFFilterElementJSON(width, height, workAreaStart, workAreaDuration, 3, 4096, pathInfo.fileName, pathInfo.path, "", "locus.oflua")
//~         filterJsons.push (filterJSON)
    }

    // mask all layer
    if (maskAllLayers.length > 0) {
        var pathInfo = saveMaskAllVideo (width, height, workAreaStart, workAreaDuration, maskAllLayers, path)
//~         var filterJSON = OFFilterElementJSON(width, height, workAreaStart, workAreaDuration, 3, 4096, pathInfo.fileName, pathInfo.path, "", "locus.oflua")
//~         filterJsons.push (filterJSON)
    }
    // mask
    var maskVideoPathInfos = []
    if (maskLayers.valueOf() != undefined) {
        maskVideoPathInfos = saveMaskVideos (width, height, workAreaStart, workAreaDuration, maskLayers, path)
        for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
            var pathInfo = maskVideoPathInfos[filePathIndex]
//~             var filterJSON = OFFilterElementJSON(width, height, workAreaStart, workAreaDuration, 3, 4096, pathInfo.fileName, pathInfo.path, "", "locus.oflua")
//~             filterJsons.push (filterJSON)
        }
    }
    
    // other layers
    for (var layerIndex = 0; layerIndex < otherLayers.length; layerIndex++) {
        var layer = otherLayers[layerIndex]
        var keyTimes = getAllKeyTimesInLayer (layer, workAreaStart)
        var animations = getAnimationFromLayer(layer, keyTimes)
        var animationFileName = escape(layer.name.replace(/\s+/g,"_"));
        // find mask video index
        var maskVideoIndex = -1
        if (maskAllLayers.length > 0) {
            maskVideoIndex = (backgroundLayers.length > 0 ? 1 : 0)
        } else {
            for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
                var pathInfo = maskVideoPathInfos[filePathIndex]
                if (pathInfo.maskdName == layer.name) {
                    maskVideoIndex = (backgroundLayers.length > 0 ? 1 : 0)  + filePathIndex + 1
                    break
                }
            }
        }
    
        // filter
        var filterJSON = oneFilter(path, workAreaStart, workAreaDuration, animationFileName, layer, maskVideoIndex)
        filterJsons.push (filterJSON)
        
        // animation
        saveAnimations(animations, path, animationFileName)
    }

    //ofeffect
    var f = new File(path + "/effect"+i.toString()+".ofeffect");
    f.open ("we", "TEXT", "");
    f.encoding = "UTF-8"
    f.write (effectHeader(filterJsons.length, duration))
    f.write (filterJsons.join (","))
    f.write(effectFooter())
    f.close();
}
var jsPath = new File($.fileName)
copyResources(jsPath.path, path)
alert("导出成功："+path);

//-------------------------------------------------------------------------------------- function -------------------------------------------
function splitLayers(compItem) {
    if (!(compItem instanceof CompItem)) {
        return [{}, [], [], []]
    }
    var maskLayers = {}
    var maskAllLayers = []
    var backgroundLayers = []
    var otherLayers = []
    for (var layerIndex = 1; layerIndex <= compItem.numLayers; layerIndex++) {
        layer = compItem.layer(layerIndex)
        if (!layer.enabled || layer instanceof CameraLayer) {
            continue
        }
        if (isMaskLayer (layer)) {
            var maskLayersForALayer = maskLayers[getMaskdLayerName(layer)]
            if (maskLayersForALayer == undefined) {
                maskLayersForALayer = []
            }
            maskLayersForALayer.push (layer)
            maskLayers[getMaskdLayerName(layer)] = maskLayersForALayer
        } else if (isMaskAllLayer(layer)) {
            maskAllLayers.push (layer)
        }
        else if (isBackgroundLayer(layer)) {
            backgroundLayers.push (layer)
        } else {
            otherLayers.push (layer)
        }
    }
    return [maskLayers, maskAllLayers, backgroundLayers, otherLayers]
}
function isMaskLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_maskVideo") > 0
}
function isBackgroundLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name=="background"
}
function isMaskAllLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_maskAllVideo") > 0
}
function getMaskdLayerName(layer) {
    if (!isMaskLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_maskVideo"))
}
function getMaskAllLayerName(layer) {
    if (!isMaskAllLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_maskAllVideo"))
}
function getBackgroundLayerName(layer) {
    if (!isBackgroundLayer(layer)) {
        return ""
    }
    return "background"
}

function saveMaskVideos(width, height, beginTime, duration, maskLayers, basePath) {
    var videoPaths = []
    for (var maskdLayerName in maskLayers) {
        var maskLayersForALayer = maskLayers[maskdLayerName]
        var fileName = maskdLayerName
        var filePathInfo = saveVideoFromLayers (maskLayersForALayer, basePath + "/res", fileName)
        var filePath = filePathInfo.filePath
        var extension = filePathInfo.extension
        fileName = escape(fileName.replace(/\s+/g,"_"))
        var resName = "res/"+ fileName + "_mask." + extension
        renameFile (filePath, basePath + "/" + resName)
        inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
        videoPaths.push ({path:resName, fileName: fileName, maskdName: maskdLayerName})
    }
    return videoPaths
}

function saveBackgroundVideo(width, height, beginTime, duration, backgroundLayers, basePath) {
    var fileName = getBackgroundLayerName(backgroundLayers[0])
    var filePathInfo = saveVideoFromLayers (backgroundLayers, basePath + "/res", fileName)
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
//~     fileName = escape(fileName.replace(/\s+/g,"_"))
    var resName = "res/"+ fileName + "." + extension
//~     renameFile (filePath, basePath+ "/" + resName)
    inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    
    return {path:resName, fileName: fileName}
}
function saveMaskAllVideo(width, height, beginTime, duration, maskAllLayers, basePath) {
    var fileName = getMaskAllLayerName(maskAllLayers[0])
    var filePathInfo = saveVideoFromLayers (maskAllLayers, basePath + "/res", fileName)
    var filePath = filePathInfo.filePath
    var extension = filePathInfo.extension
    fileName = escape(fileName.replace(/\s+/g,"_"))
    var filePathComponents = filePath.split (".")
    var resName = "res/"+ fileName + "_maskall." + extension
    renameFile (filePath, basePath+ "/" + resName)
    inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
    
    return {path:resName, fileName: fileName}
}
function OFFilterElementJSON(width, height, beginTime, duration, renderType, resType, description, relativeResPath, relativeAnimationPath, oflua, textObject) {
//~     var renderType = 1
//~     var resType = 1
//~     
//~     var textFontSize = 10
//~     var textFont = ""
//~     var text = ""
//~     var textColorR = 1.0
//~     var textColorG = 1.0
//~     var textColorB = 1.0
//~     var textBlod = "false"
//~     var textShadow = "false"
    
//~     var oflua = "locus.oflua"
    
    if (textObject == undefined) {
        textObject = {
                textFontSize : 10,
                textFont : "",
                text : "",
                textColorR : 1.0,
                textColorG : 1.0,
                textColorB : 1.0,
                textBlod : "false",
                textShadow : "false"
            }
    }
     
    return "{"+
                    "\"beginTime\":"+(beginTime*1000).toString()+","+
                    "\"endTime\":"+(parseInt((beginTime+duration)*1000)).toString()+","+
                    "\"type\":\"CustomLuaFilter\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(duration*1000)).toString()+","+
                    "\"description\":\""+description +"\","+
                    "\"paramf\":{"+
                                        "\"Width\":"+width.toString()+","+
                                        "\"Height\":"+height.toString()+""+
                                        "},"+
                    "\"parami\":{\"VideoIndex\":1,\"RenderType\":"+renderType.toString()+",\"FontSize\":"+textObject.textFontSize.toString()+",\"BlendMode\":0},"+
                    "\"parambool\":{\"FontBold\":"+textObject.textBlod+",\"FontShadow\":"+textObject.textShadow+",\"AnimationDataChanged\":true},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":"+resType.toString()+",\"resName\":\""+relativeResPath+"\"},"+
                                            "\"Music\":{\"resType\":"+resType.toString()+",\"resName\":\""+relativeResPath+"\"},"+
                                            "\"MaskTexture\":{\"resType\":1,\"resName\":\"\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\""+relativeAnimationPath+"\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":["+textObject.textColorR.toString()+","+textObject.textColorG.toString()+","+textObject.textColorB.toString()+",1]},"+
                    "\"paramstring\":{\"RenderText\":\""+textObject.text+"\",\"Font\":\""+textObject.textFont+"\"},"+
                    "\"ext_data\":{\"luaScriptName\":\""+oflua+"\"}"+
                "}";
}




function effectHeader(filterCount, duration, layer) {
    var inputFilesCount = inputFiles.length
    var inputJson = "";
    for (var ii = 0; ii < inputFiles.length; ii++) {
        inputJson += inputFiles[ii] + ","
    }
    if (inputJson.length > 0) {
        inputJson = inputJson.substr(0,inputJson.length-1)
    }
    return "{\"ofversion\":\"4.0\",\"audioName\":\"\",\"duration\":"+(duration*1000).toString()+",\"playMode\":0,\"isFadeout\":false,\"fadeoutStart\":0,\"trackDataCacheTime\":0,"+
        "\"input_count\":"+inputFilesCount.toString()+",\"input_list\":["+inputJson+"],"+
        "\"effect_paramf_count\":0,\"effect_paramf_list\":[],"+
        "\"filter_count\":"+filterCount.toString()+",\"filter_list\":[";
}
function effectFooter() {
    return "],"+
        "\"animator_count\":0,\"animator_list\":[],\"scene_count\":0,\"scene_list\":[]}";
}
function oneFilter(path, workAreaStart , workAreaDuration, animationKey, layer, maskVideoIndex) {
    var renderType = 1
    var resType = 1
    var resName= ""
    var textFontSize = 10
    var textFont = ""
    var text = ""
    var textColor = 1.0
    var textColor1 = 1.0
    var textColor2 = 1.0
    var textBlod = "false"
    var textShadow = "false"
    var oflua = "locus.oflua"
    if (isMaskLayer (layer) || isBackgroundLayer (layer)) {
        return
//~     } else if () {
//~         renderType = 3
//~         resType = 4096
//~         
//~         var outputedFile = path + "/res/" +layer.name + ".avi"
//~         saveVideoFromLayers(maskLayers[layer.name], path + "/res", layer.name)
//~          var outputFile = new File (outputedFile)
//~         if (outputFile.exists) {
//~             var oldFile = new File(path + "/res/"+animationKey+".avi")
//~             oldFile.remove()
//~             outputFile.rename(path + "/res/"+animationKey+".avi")
//~             resName = "res/"+animationKey+".avi"
//~             inputFiles.push ("{\"type\":\"video\",\"url\":\""+resName+"\"}")
//~         }
    } else if (layer instanceof ShapeLayer) { 
        renderType = 1
        resType = 1
        
        var outputedShapeFile = path + "/res/"+layer.name+".png"
        saveImageFromLayers([layer], path + "/res" , layer.name)
        var outputFile = new File (outputedShapeFile)
        if (outputFile.exists) {
            var oldFile = new File(path + "/res/" + animationKey + ".png")
            oldFile.remove()
            outputFile.rename (path + "/res/" + animationKey + ".png")
    
            resName = "res/" + animationKey + ".png"
        } else {
            alert("形状图层生成位图失败")
        }
    } else if (layer instanceof TextLayer) { 
        renderType = 6
        text = layer.sourceText.value.text.replace(/[\r\n]/g, "") 
        textFontSize = layer.sourceText.value.fontSize
        textFont = layer.sourceText.value.fontFamily
        textColor = layer.sourceText.value.fillColor[0]
        textColor1 = layer.sourceText.value.fillColor[1]
        textColor2 = layer.sourceText.value.fillColor[2]
        if (layer.sourceText.value.fontStyle.value == "Blod") {
            textBlod = "true";
        }
    } else {
       if (layer.source != undefined && layer.source.file != null) {
            var  fileName = layer.source.file.displayName
            if (fileName.indexOf(".mp3")>0 || fileName.indexOf(".wav")>0) {
                //音频
                renderType = 3
                resType = 64
                oflua  = "music.oflua"
                workAreaStart = layer.startTime
                workAreaDuration = layer.time
            } else if (fileName.indexOf(".png")>0 || fileName.indexOf(".jpg")>0) {
                //图片
                renderType = 1
                resType = 1
            } else if (fileName.indexOf(".mp4")>0 || fileName.indexOf(".avi")>0) {
                //视频
                renderType = 3
                resType = 4096
            } else {
                type = 1
            }
            
            //copy File
            var ofPath = "res/" +  escape(fileName.replace(/\s+/g,"_"));
            var copyPath = path + "/" + ofPath
            layer.source.file.copy (copyPath)
            resName = ofPath
        }
    }
    return "{"+
                    "\"beginTime\":"+(workAreaStart*1000).toString()+","+
                    "\"endTime\":"+(parseInt((workAreaStart+workAreaDuration)*1000)).toString()+","+
                    "\"type\":\"CustomLuaFilter\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(workAreaDuration*1000)).toString()+","+
                    "\"description\":\""+layer.name +"\","+
                    "\"paramf\":{"+
                                        "\"Width\":"+layer.width.toString()+","+
                                        "\"Height\":"+layer.height.toString()+","+
                                        "\"ScaleX\": 1.0,"+
                                        "\"ScaleY\": 1.0,"+
                                        "\"TranslateX\": 0.0,"+
                                        "\"TranslateY\": 0.0,"+
                                        "\"RotateX\": 0.0,"+
                                        "\"RotateY\": 0.0,"+
                                        "\"RotateZ\": 0.0,"+
                                        "\"Alpha\": 1.0,"+
                                        "\"BlurRadius\": 0.0,"+
                                        "\"BlurWidthOffset\": 1.0,"+
                                        "\"BlurHeightOffset\": 1.0,"+
                                        "\"MaskScaleX\": 1.0,"+
                                        "\"MaskScaleY\": 1.0,"+
                                        "\"MaskTranslateX\": 0.0,"+
                                        "\"MaskTranslateY\": 0.0,"+
                                        "\"MaskRotateX\": 0.0,"+
                                        "\"MaskRotateY\": 0.0,"+
                                        "\"MaskRotateZ\": 0.0,"+
                                        "\"MaskAlpha\": 1.0"+
                                        "},"+
                    "\"parami\":{"+
                                        "\"VideoIndex\":1,"+
                                        "\"RenderType\":"+renderType.toString()+","+
                                        "\"FontSize\":"+textFontSize.toString()+","+
                                        "\"BlendMode\":0,"+
                                        "\"MaskRenderType\":3, "+
                                        "\"MaskVideoIndex\":" + maskVideoIndex + 
                                        "},"+
                    "\"parambool\":{\"FontBold\":"+textBlod+",\"FontShadow\":"+textShadow+",\"AnimationDataChanged\":true},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"Music\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"MaskTexture\":{\"resType\":1,\"resName\":\"\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\"res/"+animationKey.toString()+".ofanim\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":["+textColor.toString()+","+textColor1.toString()+","+textColor2.toString()+",1]},"+
                    "\"paramstring\":{\"RenderText\":\""+text+"\",\"Font\":\""+textFont+"\"},"+
                    "\"ext_data\":{\"luaScriptName\":\""+oflua+"\"}"+
                "}";
}


//------------------------------------------------------------------------ animations ------------------------------------------
function valueAtTime(layer, propertyName, time) {
    if (time < 0) { 
        return undefined
    }
    if (!layer.transform.hasOwnProperty (propertyName) || layer.transform[propertyName] == null) {
        return undefined
    }
    property = layer.transform[propertyName]
    return property.valueAtTime(time, false)
}
function saveAnimations(animations, basePath, fileName) {
    var animationFile = new File(basePath + "/res/"+fileName+".ofanim");
    animationFile.open ("we", "", "")
    var animationJson = animationHeader(animations.length)
    var animationList = []
    for (var kk = 0; kk < animations.length; kk++) {
        animationList.push(oneAnimation (animations[kk]))
    }
    animationJson += animationList.join (",")
    animationJson += animationFooter();
    animationFile.write(animationJson)
    animationFile.close();
}
function getAllKeyTimesInLayer(layer, workAreaStart) {
    if (layer == null || !layer.enabled) {
        return []
    }
    var keyTimes = []
    for (var k = 0; k < transformProperties.length; k++) {
        if (layer.transform.hasOwnProperty (transformProperties[k])) {
            transformProperty = layer.transform[transformProperties[k]]
            propertyValue = transformProperty.value
            for (var l = 1; l <= transformProperty.numKeys; l++) {
                keyTime = transformProperty.keyTime(l)
                var duplicated = false
                for (var timeIndex in keyTimes) {
                    if (keyTimes[timeIndex] == keyTime) {
                        duplicated = true
                        break
                    }
                }
                if (!duplicated && keyTime >= 0 && keyTime >= workAreaStart && keyTime <= (workAreaStart + workAreaDuration)) { 
                    keyTimes.push(keyTime);
                }
            }
        }
    }

    function sortKeyTime(a, b) {
        if (a > b) return 1
        else if (a < b) return -1
        else return 0
    }
    keyTimes.sort(sortKeyTime)
    if (keyTimes.length > 0) {
        if (keyTimes[0]>workAreaStart) {
            var tmp = keyTimes.reverse()
            tmp.push(workAreaStart)
            keyTimes = tmp.reverse()
        }
    } else {
        keyTimes.push(workAreaStart)
    }
    return keyTimes
}
function getAnimationFromLayer(layer, keyTimes) {
    if (keyTimes.length <= 0) {
        return []
    }
    var animations = []
    var basePointX = -1;
    var basePointY = -1;
    for (var keyTimeIndex = 0; keyTimeIndex < keyTimes.length; keyTimeIndex++) {
        var animation = []
        var keyTime = keyTimes[keyTimeIndex]
        animation["keyTime"] = keyTime
        for (var propertyIndex = 0; propertyIndex < transformProperties.length; propertyIndex++) {
            propertyName = transformProperties[propertyIndex]
            value = valueAtTime (layer, propertyName, keyTime)
            if (value == undefined) {
                continue
            }
            animation[propertyName] = value
        }
        animations.push(animation)
    }
    var width = layer.width
    var height = layer.height
    if (layer instanceof TextLayer) {
        var sourceRect = layer.sourceRectAtTime(keyTimes[0], true)
        width = 0
        height = 0
    }
    for (var i = 0; i < animations.length ; i++) {
//~             if (propertyName == "position") {
//~                 if (basePointX < 0) {
//~                     basePointX = value[0]
//~                 }
//~                 if (basePointY < 0) {
//~                     basePointY = value[1]
//~                 }
//~             }
            var aeX = animations[i]["position"][0] - (animations[i]["anchorPoint"][0] - width/2.0)
            var aeY = animations[i]["position"][1] - (animations[i]["anchorPoint"][1] - height/2.0)
            animations[i]["translateX"] = aeX - layer.containingComp.width/2.0
            animations[i]["translateY"] = aeY - layer.containingComp.height/2.0
    }

    return animations
}
function animationHeader(keyCount) {
    return "{\"version\":1,\"smoothMode\":1,\"keyCount\":"+keyCount.toString()+",\"keys\":[";
}
function animationFooter() {
    return "]}";
}
function oneAnimation(animate) {
    return "{"+
                    "\"time\":"+animate.keyTime.toString()+","+
                    "\"translateX\":"+animate.translateX.toString()+","+
                    "\"translateY\":"+animate.translateY.toString()+","+
                    "\"scaleX\":"+(animate.scale[0]/100.0).toString()+","+
                    "\"scaleY\":"+(animate.scale[1]/100.0).toString()+","+
                    "\"rotateX\":"+(animate.rotation != undefined ? animate.rotation.toString() : "0")+","+
                    "\"rotateY\":0,"+
                    "\"rotateZ\":0,"+
                    "\"alpha\":1,"+
                    "\"maskTranslateX\":0,"+
                    "\"maskTranslateY\":0,"+
                    "\"maskScaleX\":1,"+
                    "\"maskScaleY\":1,"+
                    "\"maskRotateX\":0,"+
                    "\"maskRotateY\":0,"+
                    "\"maskRotateZ\":0,"+
                    "\"maskAlpha\":1,"+
                    "\"blurRadius\":0,"+
                    "\"blurWidthOffset\":0,"+
                    "\"blurHeightOffset\":0"+
                "}";
}



//------------------------------------------------------------------------ shapelayer & mp4 ------------------------------------------
function saveVideoFromLayers(layers, path, fileName) {
    var filePathWithFileName = path + "/" + fileName + ".avi"
    var path = exportLayers(layers, filePathWithFileName, -1)
    var mp4Path = path.replace (".avi", ".mp4")
    system.callSystem("ffmpeg -i \""+path+"\" -strict -2 -pix_fmt yuv420p \""+mp4Path + "\"")
    var aviFile = new File(path)
    if (aviFile.exists) {
        aviFile.remove()
    }
    return {filePath: mp4Path, extension:"mp4"}
}

function saveImageFromLayers(layers, path, fileName) {
    var containingComp = layer.containingComp
    var originDuration = containingComp.workAreaDuration
    containingComp.workAreaDuration = 0.04
    var filePathWithFileName = path + "/" + fileName + "[#####].png"
    exportLayers(layers, filePathWithFileName, 14)
    containingComp.workAreaDuration = originDuration
    
    var frameIndex = (containingComp.workAreaStart*containingComp.frameRate) .toString()
    var fullFrameIndex = ""
    for (var i = 0; i < (5-frameIndex.length); i++) {
        fullFrameIndex += "0"
    }
    fullFrameIndex += frameIndex
    var imageFile = new File(path + "/" + fileName + fullFrameIndex + ".png")
    var newName = path + "/" + fileName + ".png"
    imageFile.rename (newName)
    return newName
}

function exportLayers(layers, filePathWithFileName, usingTemplateIndex) {
    var containingComp = layer.containingComp
    var originLayerEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        alayer.enabled = false
    }
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var alayer = layers[layerIndex]
        alayer.enabled = true
    }
    var renderQueue = app.project.renderQueue
    renderQueue.items.add(containingComp)
    var renderItem = app.project.renderQueue.item(app.project.renderQueue.numItems)
    var outputModule = renderItem.outputModule(1)
    if (usingTemplateIndex >= 0) {
        outputModule.applyTemplate(outputModule.templates[usingTemplateIndex])
    }
    outputModule.file = new File(filePathWithFileName)
    renderQueue.render()
    renderItem.remove()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
    }
    return filePathWithFileName
}

//------------------------------------------------------------------------ utils ------------------------------------------
function copyResources(srcPath, destPath) {
    var resources = ["locus.oflua", "music.oflua"]
    for (var resourceIndex = 0;  resourceIndex < resources.length; resourceIndex++) {
        var resource = resources[resourceIndex]
        var resourceFile = new File(srcPath + "/" + resource)
        resourceFile.copy (destPath + "/" + resource)
    }
}

function resetFolderIfNeed(path) {
    if (app.project.file == undefined) {
        alert("请保存文件");
    }
    var folder = new Folder(path);
    if  (folder.exists) {
        var files = folder.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File) {
                files[i].remove()
            }
        }
        folder.remove ();
    }
    folder.create();
    
    var res = new Folder(path+"/res");
    if  (res.exists) {
        var files = res.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File) {
                files[i].remove()
            }
        }
        res .remove ();
    }
    res.create();
}

function renameFile(filePath, newFilePath) {
    if (filePath == newFilePath) {
        return true
   }
    var file = new File (filePath)
    if (file.exists) {
        var oldFile = new File(newFilePath)
        oldFile.remove()
        file.rename(newFilePath)
        return true
    } else {
        return false
    }
}

function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16).toUpperCase();
    });
}