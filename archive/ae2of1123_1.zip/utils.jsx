﻿
function renameFile(filePath, newFilePath) {
    if (filePath == newFilePath) {
        return true
   }
    var file = new File (filePath)
    if (file.exists) {
        var oldFile = new File(newFilePath)
        oldFile.remove()
        file.rename(newFilePath)
        return true
    } else {
        return false
    }
}

function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16).toUpperCase();
    });
}

Array.prototype.contains = function (element) {
    if (this.length == 0 || element == undefined || element == null) {
        return false
    }
    for (var index = 0; index < this.length; index++) {
        if (this[index] === element) {
            return true
        }
    }
    return false
} 