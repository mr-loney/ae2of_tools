﻿#include "utils.jsx"
#include "webm.jsx"
#include "png_tool.jsx"
#include "json2.jsx"

var transformProperties = ["position", "anchorPoint", "scale", "rotation", "xRotation", "yRotation", "zRotation", "opacity"]
var effectProperties = ["ADBE Gaussian Blur 2"]

function effectHeader(filterCount, duration, layer) {
    var inputFilesCount = 0;
    var inputJson = "" ;
    if (needMergeVideo()) {//合并方案
        inputFilesCount = 1
        inputJson += "{\"type\":\"video\",\"url\":\""+resMergedVideoPath+"\"},"
    } else {
        inputFilesCount = uiinfo_video.length
        for (var ii = 0; ii < uiinfo_video.length; ii++) {
             inputJson += "{\"type\":\"video\",\"url\":\""+uiinfo_video[ii].filePath+"\"},"
        }
    }
    if (inputJson.length > 0) {
        inputJson = inputJson.substr(0,inputJson.length-1)
    }
    return "{\"ofversion\":\"4.0\",\"audioName\":\"\",\"duration\":"+(parseInt(duration*1000)).toString()+",\"playMode\":0,\"isFadeout\":false,\"fadeoutStart\":0,\"trackDataCacheTime\":0,"+
        "\"input_count\":"+inputFilesCount.toString()+",\"input_list\":["+inputJson+"],"+
        "\"effect_paramf_count\":0,\"effect_paramf_list\":[],"+
        "\"filter_count\":"+filterCount.toString()+",\"filter_list\":[";
}
function effectFooter() {
    return "],"+
        "\"animator_count\":0,\"animator_list\":[],\"scene_count\":0,\"scene_list\":[]}";
}
function oneFilter(path, animationKey, layer, maskType, maskRes) {
    var renderType = 1
    var resType = 1
    var resName= ""
    var textFontSize = 10
    var textFont = ""
    var text = ""
    var textColor = 1.0
    var textColor1 = 1.0
    var textColor2 = 1.0
    var textBlod = "false"
    var textShadow = "false"
    var textJustification = "2"//对齐方式 0=左对齐，1=右对齐， 2=居中
    var textFontVertical = "false"///0 = 横排   ，  1 = 竖排
    var textMaskFontVertical = "false"///0 = 横排   ，  1 = 竖排
    var oflua = "locus.oflua"
    var speed = 1.0
    var videoIndex = 1
    var workAreaStart = layer.inPoint
    var isMirror = "false"
    var luaType = "CustomLuaFilter"
    var webmFile = ""
    if (workAreaStart<0) {
        workAreaStart = 0
    }
    var workAreaDuration = layer.outPoint -workAreaStart
    var beginTime = parseInt(workAreaStart*1000)
    var blur = getOFGaussianBlurFromLayer (layer)
    var blendMode = "0"
    if (layer.blendingMode==BlendingMode.SCREEN) {
        blendMode = "7"
    } else if (layer.blendingMode==BlendingMode.ADD) {
        blendMode = "3"
    } else if (layer.blendingMode==BlendingMode.SOFT_LIGHT) {
        blendMode = "4"
    }
    if (isMaskLayer (layer) || isBackgroundLayer (layer)) {
        return
    } else if (layer instanceof ShapeLayer) { 
        renderType = 1
        resType = 1
        
        var outputedShapeFile = path + "/res/"+layer.name+".png"
        saveImageFromLayers([layer], path + "/res" , layer.name)
        var outputFile = new File (outputedShapeFile)
        if (outputFile.exists) {
            if (animationKey != layer.name) {
                var oldFile = new File(path + "/res/" + animationKey + ".png")
                oldFile.remove()
                outputFile.rename (path + "/res/" + animationKey + ".png")
            }
            resName = "res/" + animationKey + ".png"
        } else {
            alert("形状图层生成位图失败"+layer.name);
        }
    } else if (layer instanceof TextLayer) { 
        renderType = 6
        text = layer.sourceText.value.text.replace(/[\r\n]/g, "\\n") .replace(/[]/g, "\\n") 
        textFontSize = Math.round(layer.sourceText.value.fontSize)
        textFont = layer.sourceText.value.fontFamily
        textFontLocation = layer.sourceText.value.fontLocation
        if (textFontLocation.length > 0) {
            var ttf = new File(textFontLocation)
            if (ttf.exists) {
                var copyPath = path + "/res/" + textFont + ".ttf"
                ttf.copy (copyPath)
            }
            textFont = "res/" + textFont + ".ttf"
        }
        textColor = layer.sourceText.value.fillColor[0]
        textColor1 = layer.sourceText.value.fillColor[1]
        textColor2 = layer.sourceText.value.fillColor[2]
        if (layer.sourceText.value.fauxBold) {
            textBlod = "true";
        }
        
        //判断是否竖向排列
        var sourceRect = layer.sourceRectAtTime(0.0, true)
        if (sourceRect.height > sourceRect.width && layer.sourceText.value.text.length>1) {
            textFontVertical = "true"
            textMaskFontVertical = "true"
        }
//~         var locs = layer.sourceText.value.baselineLocs
//~         var locs0 = layer.sourceText.value.baselineLocs[0]
//~         var locs1 = layer.sourceText.value.baselineLocs[1]
//~         var locs2 = layer.sourceText.value.baselineLocs[2]
//~         var locs3 = layer.sourceText.value.baselineLocs[3]
//~         if (locs1<0 && locs3>0) {
//~             textFontVertical = "true"
//~             textMaskFontVertical = "true"
//~         }
    
        //对齐方式
        var just = layer.sourceText.value.justification
        switch (just) {
            case ParagraphJustification.CENTER_JUSTIFY:
                textJustification = "2";
                break;
            case ParagraphJustification.LEFT_JUSTIFY:
                textJustification = "0";
                break;
            case ParagraphJustification.RIGHT_JUSTIFY:
                textJustification = "1";
                break;
            default:
                textJustification = "2";
                break;
        }
    
    } else {
       if (layer.source != undefined && layer.source.file != null) {
            var  fileName = layer.source.file.displayName
            //copy File
            var ofPath = "res/" +  nameWithRight(fileName);
            var copyPath = path + "/" + ofPath
            layer.source.file.copy (copyPath)
            resName = ofPath
            
            if (fileName.indexOf(".mp3")>0 || fileName.indexOf(".wav")>0) {
                //音频
                renderType = 3
                resType = 64
                oflua  = "music.oflua"
                workAreaStart = layer.startTime
                if (workAreaStart<0) {
                    workAreaStart = 0
                }
                if (layer.time > 0) {
                    workAreaDuration = layer.time
                }
                uiinfo_music.push ("{\"beginTime\":\""+(beginTime<0 ? 0 : beginTime).toString()+"\",\"endTime\":\""+(parseInt((workAreaStart+workAreaDuration)*1000)).toString()+"\",\"name\":\""+resName+"\"}")
     
            } else if (fileName.indexOf(".png")>0 || fileName.indexOf(".jpg")>0) {
                //图片
                renderType = 1
                resType = 1
                if (layer.source.file.length > (100 * 1000)) {//文件大于100K，进行压缩
                    pngCompress(copyPath)
                }
            } else if (fileName.indexOf(".mp4")>0 || fileName.indexOf(".avi")>0) {
                //视频
                renderType = 3
                resType = 4096
                
                //转码
                var tmpPath = copyPath.replace(".mp4","_new.mp4").replace(".avi","_new.mp4")
                transformVideoWithFFMPEG(copyPath, tmpPath, 0, 0, false)
                var oldFile = new File(copyPath)
                if (oldFile.exists) {
                    oldFile.remove()
                }
                var newFile = new File(tmpPath)
                newFile.rename(copyPath)
                
                var foundIndex = -1;
                for (var ii = 0; ii < uiinfo_video.length; ii ++) {
                    if (uiinfo_video[ii].filePath == resName) {
                        foundIndex = ii;
                    }
                }
                if (foundIndex>=0) {
                    videoIndex = foundIndex+1;
                } else {
                    var videoInfo = {
                        "beginTime":(beginTime<0 ? 0 : beginTime).toString(),
                        "endTime":(parseInt((workAreaStart+workAreaDuration)*1000)).toString(),
                        "filePath":resName,
                        "audioEnable":layer.audioActive
                        };
                    var size = readSize(path+"/"+resName);
                    if (size.width > 0) {
                        videoInfo.width = size.width;
                        videoInfo.height = size.height;
                    }
                    uiinfo_video.push(videoInfo)
                    videoIndex = uiinfo_video.length
                }
            } else if (fileName.indexOf(".mov")>0) {
                //视频
                renderType = 3
                resType = 4096
                var webmFile = mov2webm(copyPath,  layer.width,  layer.height)
                resName = webmFile.replace(path + "/", "");
                oflua = "";
                isMirror = "true";
                webmFile = resName;
                luaType = "BlendAnimationFilter";
                
                var foundIndex = -1;
                for (var ii = 0; ii < uiinfo_video.length; ii ++) {
                    if (uiinfo_video[ii].filePath == resName) {
                        foundIndex = ii;
                    }
                }
                if (foundIndex>=0) {
                    videoIndex = foundIndex+1;
                } else {
                    var videoInfo = {
                        "beginTime":(beginTime<0 ? 0 : beginTime).toString(),
                        "endTime":(parseInt((workAreaStart+workAreaDuration)*1000)).toString(),
                        "filePath":resName,
                        "audioEnable":layer.audioActive
                        };
                    var size = readSize(path+"/"+resName);
                    if (size.width > 0) {
                        videoInfo.width = size.width;
                        videoInfo.height = size.height;
                    }
                    uiinfo_video.push(videoInfo)
                    videoIndex = uiinfo_video.length
                }
            } else {
                type = 1
            }
        }
    }
    var begin = (beginTime<0 ? 0 : beginTime);
    var end = parseInt((workAreaStart+workAreaDuration)*1000);
    if (end <= 0) {
        throw "wrong area ["+workAreaStart+", "+workAreaDuration+"]";
    }
    return "{"+
                    "\"beginTime\":"+begin.toString()+","+
                    "\"endTime\":"+end.toString()+","+
                    "\"type\":\""+luaType+"\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(workAreaDuration*1000)).toString()+","+
                    "\"description\":\""+layer.name +"\","+
                    "\"paramf\":{"+
                                        "\"PlaySpeed\":"+speed.toString()+","+
                                        "\"Width\":"+layer.width.toString()+","+
                                        "\"Height\":"+layer.height.toString()+","+
                                        "\"ScaleX\": 1.0,"+
                                        "\"ScaleY\": 1.0,"+
                                        "\"TranslateX\": 0.0,"+
                                        "\"TranslateY\": 0.0,"+
                                        "\"RotateX\": 0.0,"+
                                        "\"RotateY\": 0.0,"+
                                        "\"RotateZ\": 0.0,"+
                                        "\"Alpha\": 1.0,"+
                                        "\"BlurRadius\": " + blur[0].toString() + ","+
                                        "\"BlurWidthOffset\": " + blur[1].toString() + ","+
                                        "\"BlurHeightOffset\": " + blur[2].toString() + ","+
                                        "\"MaskScaleX\": 1.0,"+
                                        "\"MaskScaleY\": 1.0,"+
                                        "\"MaskTranslateX\": 0.0,"+
                                        "\"MaskTranslateY\": 0.0,"+
                                        "\"MaskRotateX\": 0.0,"+
                                        "\"MaskRotateY\": 0.0,"+
                                        "\"MaskRotateZ\": 0.0,"+
                                        "\"MaskAlpha\": 1.0"+
                                        "},"+
                    "\"parami\":{"+
                                        "\"VideoIndex\":"+videoIndex.toString()+","+
                                        "\"RenderType\":"+renderType.toString()+","+
                                        "\"FontSize\":"+textFontSize.toString()+","+
                                        "\"FontAlign\":"+textJustification+","+
                                        "\"BlendMode\":"+blendMode+ 
                                        (maskType == ExportType.text ? (",\"MaskFontAlign\":" + maskRes.align): "") + 
                                        (maskType == ExportType.text ? (",\"MaskFontSize\":" + maskRes.fontSize) : "") + 
                                        (maskType == ExportType.video ? (",\"MaskRenderType\":3,\"MaskVideoIndex\":" + maskRes.toString()) : "") + 
                                        (maskType == ExportType.text ? (",\"MaskRenderType\":4,\"MaskVideoIndex\":1") : "") + 
                                        "},"+
                    "\"parambool\":{"+
                                        "\"FontBold\":"+textBlod+","+
                                        "\"FontShadow\":"+textShadow+","+
                                        "\"FontVertical\":"+textFontVertical+","+
                                         (maskType == ExportType.text ? ("\"MaskFontVertical\":" + maskRes.vertical + ",") : "") +
                                         (maskType == ExportType.text ? ("\"MaskFontBold\":" + maskRes.bold + ",") : "") +
                                        "\"AnimationDataChanged\":true"+
                                        "},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"Music\":{\"resType\":"+resType.toString()+",\"resName\":\""+resName+"\"},"+
                                            "\"MaskTexture\":{\"resType\":" + maskType.toString() + ",\"resName\":\"" + maskRes.toString() + "\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\"res/"+animationKey.toString()+".ofanim\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":["+textColor.toString()+","+textColor1.toString()+","+textColor2.toString()+",1]},"+
                    "\"paramstring\":{"+
                                            (needMergeVideo() && false ? "\"VideoConfig\":\""+getMergedVideoRect().replace(/["]/g, "\\\"")+"\"," : "")+
                                            "\"RenderText\":\""+text+"\","+
                                            "\"Font\":\""+textFont+"\"" +
                                         (maskType == ExportType.text ? (",\"MaskRenderText\":\"" + maskRes.text + "\"") : "") + 
                                         (maskType == ExportType.text ? (",\"MaskFont\":\"" + maskRes.font + "\"") : "") + 
                                         "},"+
                    "\"ext_data\":{"+
                                        "\"webmFile\":\""+webmFile+"\","+
                                        "\"isMirror\":"+isMirror+","+
                                        "\"timeInterval\": 33,"+
                                        "\"luaScriptName\":\""+oflua+"\""+
                                        "}"+
                "}";
}

//------------------------------------------------------------------------ animations ------------------------------------------
function valueAtTime(layer, propertyName, time) {
    if (time < 0) { 
        return undefined
    }
    if (!layer.transform.hasOwnProperty (propertyName) || layer.transform[propertyName] == null) {
        return undefined
    }
    property = layer.transform[propertyName]
    return property.valueAtTime(time, false)
}
function saveAnimations(animations, basePath, fileName) {
    var animationFile = new File(basePath + "/res/"+fileName+".ofanim");
    animationFile.open ("we", "", "")
    var animationJson = animationHeader(animations)
    var animationList = []
    for (var kk = 0; kk < animations.length; kk++) {
        animationList.push(oneAnimation (animations[kk]))
    }
    animationJson += animationList.join (",")
    animationJson += animationFooter();
    animationFile.write(animationJson)
    animationFile.close();
}
function sortKeyTime(a, b) {
    if (a > b) return 1
    else if (a < b) return -1
    else return 0
}
function getAllKeyTimes(layer, workAreaStart) {
    var keyTimes = []
    if (layer.parent) {
        keyTimes = getAllKeyTimes(layer.parent, workAreaStart)
    }
    keyTimes = keyTimes.uniqueConcat(getAllKeyTimesInLayer(layer, workAreaStart))
    keyTimes.sort(sortKeyTime)
    return keyTimes
}
function getAllKeyTimesInLayer(layer, workAreaStart) {
    if (layer == null) {
        return []
    }
    var keyTimes = []
    for (var k = 0; k < transformProperties.length; k++) {
        if (layer.transform.hasOwnProperty (transformProperties[k])) {
            var transformProperty = layer.transform[transformProperties[k]]
            var propertyValue = transformProperty.value
            for (var l = 1; l <= transformProperty.numKeys; l++) {
                var keyTime = transformProperty.keyTime(l)
                if (!keyTimes.contains(keyTime) && keyTime >= 0 && keyTime >= workAreaStart && keyTime <= (workAreaStart + workAreaDuration)) { 
                    keyTimes.push(keyTime);
                }
            }
        }
    }

    for (var k = 0; k < effectProperties.length; k++) {
        if (layer.effect.hasOwnProperty (effectProperties[k])) {
            var gaussianBlurEffectBlurProperty = layer.effect[effectProperties[k]].property("ADBE Gaussian Blur 2-0001")
            for (var l = 1; l <= gaussianBlurEffectBlurProperty.numKeys; l++) {
                var keyTime = gaussianBlurEffectBlurProperty.keyTime(l)
                if (!keyTimes.contains(keyTime) && keyTime >= 0 && keyTime >= workAreaStart && keyTime <= (workAreaStart + workAreaDuration)) { 
                    keyTimes.push(keyTime);
                }
            }
        }
    }

    var frameDuration = layer.containingComp.frameDuration
    if ((!layer instanceof TextLayer && !layer.transform.anchorPoint.value.equalsTo([layer.width / 2.0, layer.height / 2.0, 0]) || 
        layer instanceof TextLayer && !layer.transform.anchorPoint.value.equalsTo([0, 0, 0])) &&
        (layer.transform.scale.numKeys > 1 || layer.transform.rotation.numKeys > 1)) {
            // 锚点不在图层中点且有缩放或旋转动画的，都要转为序列帧
        for (var i = 0; i <= (workAreaStart + workAreaDuration); i += frameDuration) {
            if (!keyTimes.contains(i)) {
                keyTimes.push(i);
            }
        }
    }

    keyTimes.sort(sortKeyTime)
    if (keyTimes.length > 0) {
        if (keyTimes[0]>workAreaStart) {
            var tmp = keyTimes.reverse()
            tmp.push(workAreaStart)
            keyTimes = tmp.reverse()
        }
    } else {
        keyTimes.push(workAreaStart)
    }
    return keyTimes
}
function getAnimationFromLayer(layer, keyTimes) {
    if (keyTimes.length <= 0) {
        return []
    }
    var animations = []
//~     var parentAnimations = []
//~     if (layer.parent) {
//~         parentAnimations = getAnimationFromLayer(layer.parent, keyTimes)
//~     }
    for (var keyTimeIndex = 0; keyTimeIndex < keyTimes.length; keyTimeIndex++) {
        var animation = []
        var keyTime = keyTimes[keyTimeIndex]
        animation["keyTime"] = keyTime
        for (var propertyIndex = 0; propertyIndex < transformProperties.length; propertyIndex++) {
            var propertyName = transformProperties[propertyIndex]
            var value = valueAtTime (layer, propertyName, keyTime)
            if (value == undefined) {
                continue
            }
            
            animation[propertyName] = value
        }
        if (layer.effect.hasOwnProperty (effectProperties[0])) {
            var gaussianBlurEffectBlurProperty = layer.effect[effectProperties[0]].property("ADBE Gaussian Blur 2-0001")
            animation["gasblur"] = gaussianBlurEffectBlurProperty.valueAtTime(keyTime, false)
            animation["blurDirection"] = layer.effect[effectProperties[0]].property("ADBE Gaussian Blur 2-0002").valueAtTime(keyTime, false)
        }
        animations.push(animation)
    }
    var width = layer.width
    var height = layer.height
    var xBias = 0
    var yBias = 0
    if (layer instanceof TextLayer) {
        var sourceRect = layer.sourceRectAtTime(keyTimes[0], true)
        var w = sourceRect.width
        var h = sourceRect.height
        width = 0
        height = 0
        var just = layer.sourceText.value.justification
        // 文字图层默认锚点（0,0）其实是相对于图层的（width/2.0, height），跟一般图层不一致，所以要修正
        var isVerticalLayout = sourceRect.height > sourceRect.width && layer.sourceText.value.text.length>1
        
        switch (just) {
            case ParagraphJustification.LEFT_JUSTIFY:
                if (isVerticalLayout) {
                    // 垂直文字
                    xBias = 0
                    yBias = h / 2.0
                } else {        
                    // 水平文字
                    xBias = w / 2.0
                    yBias = -h / 2.0
                }
                
                break;
            case ParagraphJustification.RIGHT_JUSTIFY:
                if (isVerticalLayout) {
                    // 垂直文字
                    xBias = 0
                    yBias = -h / 2.0
                } else {        
                    // 水平文字
                    xBias = -w / 2.0
                    yBias = -h / 2.0
                }
                break;
            case ParagraphJustification.CENTER_JUSTIFY:
                if (isVerticalLayout) {
                    // 垂直文字
                    xBias = 0
                    yBias = 0
                } else {        
                    // 水平文字
                    xBias = 0
                    yBias = -h / 2.0
                }
                break;
            default:
                
                break
        }        
        
    } else if (layer instanceof ShapeLayer) {
        xBias = -(animations[0]["position"][0] - (animations[0]["anchorPoint"][0] - width/2.0))
        yBias = -(animations[0]["position"][1] - (animations[0]["anchorPoint"][1] - height/2.0))
    }
    // AE转换OF坐标：1. 获取center中点位置 2. 转化为画布中点为原点的坐标
    for (var i = 0; i < animations.length ; i++) {
        var centerX = animations[i]["position"][0] - (animations[i]["anchorPoint"][0] - width/2.0)
        var centerY = animations[i]["position"][1] - (animations[i]["anchorPoint"][1] - height/2.0)
        
        if (layer instanceof TextLayer) {
            var sourceRect = layer.sourceRectAtTime(animations[i]["keyTime"], true)
            centerX = centerX + sourceRect.left + sourceRect.width / 2.0
            centerY = centerY + sourceRect.top + sourceRect.height / 2.0
        }
        if (animations[i]["gasblur"] != undefined) {
            animations[i]["gasblur"] = toOFGaussianBlur (animations[i]["gasblur"], animations[i]["blurDirection"])
        } else {
            animations[i]["gasblur"] = [0, 1, 1]
        }
        if (!animations[i].hasOwnProperty ("rotation")) {
            // 3D对象
            animations[i]["rotation"] = animations[i]["zRotation"]
        }
        var rotate = -animations[i]["rotation"]  * Math.PI / 180
        
        var matrix = new Matrix()
        matrix.reset()
        matrix.translate(-animations[i]["position"][0], -animations[i]["position"][1])
        // AE 绕z轴旋转正角度是顺时针，无论scale是正是负，与一般不同
        var signX = 1
        var signY = 1
        if (animations[i]["scale"][0] < 0) {
            signX = -1
        }
        if (animations[i]["scale"][1] < 0) {
            signY = -1
        }
        matrix.rotate(rotate*signX*signY)
//~             matrix.rotateZ(rotate)
//~             matrix.translate(animations[i]["position"][0], animations[i]["position"][1])
//~             matrix.translate(-animations[i]["position"][0], -animations[i]["position"][1])
        matrix.scale(animations[i]["scale"][0] / 100.0, animations[i]["scale"][1] / 100.0)
        matrix.translate(animations[i]["position"][0], animations[i]["position"][1])
        
        var position = matrix.applyToPoint(centerX, centerY, 0)
        var ofPosition = convertAECoordinateToOFCoordinate([position.x, position.y, 0], {width: layer.containingComp.width, height: layer.containingComp.height})
        animations[i]["translateX"] = ofPosition[0]
        animations[i]["translateY"] = ofPosition[1]
    }

//~     if (Object.keys(parentAnimations) != "") {
//~         for (var keyTimeIndex = 0; keyTimeIndex < keyTimes.length; keyTimeIndex++) {
//~             var animation = animations[keyTimeIndex]
//~             var parentAnimation = parentAnimations[keyTimeIndex]
//~             var keyTime = keyTimes[keyTimeIndex]

//~             animation["translateX"] = parentAnimation["position"][0] + animation["position"][0] - (animation["anchorPoint"][0] - width/2.0) - layer.containingComp.width/2.0
//~             animation["translateY"] = parentAnimation["position"][1] + animation["position"][1] - (animation["anchorPoint"][1] - height/2.0) - layer.containingComp.height/2.0
//~             animation["scale"] = parentAnimation["scale"].mutiply(animation["scale"]).devidedBy(100)
//~             
//~             animation["rotation"] = animation["rotation"] + parentAnimation["rotation"]
//~             
//~             animations[keyTimeIndex] = animation
//~         }
//~     }
    return animations
}
function convertAECoordinateToOFCoordinate(center, canvasSize) {
    return [center[0] - canvasSize.width/2.0,  center[1] - canvasSize.height/2.0]
}
function animationHeader(animate) {
    var smoothMode = 2
//~     var maxInterval = 0
//~     for (var i = 1 ; i < animate.length ; i++) { //忽略第0帧
//~        if (i>2) {
//~            var interval = animate[i].keyTime - animate[i-1].keyTime
//~            if (interval > maxInterval) {
//~                maxInterval = interval
//~            }
//~        }
//~     }
//~     if (maxInterval > 0.1) {
        smoothMode = 0;
//~     }
    return "{\"version\":1,\"smoothMode\":"+smoothMode.toString()+",\"keyCount\":"+animate.length.toString()+",\"keys\":[";
}
function animationFooter() {
    return "]}";
}
function oneAnimation(animate) {
    var angle = (animate.rotation != undefined ? animate.rotation.toString() : "0")
//~     var rotate = angle * 0.0174
    // AE 绕z轴旋转正角度是顺时针，无论scale是正是负，与一般不同
//~     angle = -angle*animate["scale"][0]*animate["scale"][1]/Math.abs(animate["scale"][0])/Math.abs(animate["scale"][1])
    var rotate = toRadian(angle)
    var time = animate.keyTime - 0.001
    if (time < 0) {
        time = 0
    }
    return "{"+
                    "\"time\":"+ time.toString() +","+
                    "\"translateX\":"+animate.translateX.toString()+","+
                    "\"translateY\":"+animate.translateY.toString()+","+
                    "\"scaleX\":"+(animate.scale[0]/100.0).toString()+","+
                    "\"scaleY\":"+(animate.scale[1]/100.0).toString()+","+
                    "\"rotateX\":" + (animate.hasOwnProperty ("xRotation") ? toRadian(animate.xRotation).toString() : "0") + "," +
                    "\"rotateY\":" + (animate.hasOwnProperty ("yRotation") ? toRadian(animate.yRotation).toString() : "0") + "," +
                    "\"rotateZ\":"+ rotate+","+
                    "\"alpha\":"+(animate.opacity/100.0).toString()+","+
                    "\"maskTranslateX\":" + (animate.hasOwnProperty ("maskTranslateX") ? animate.maskTranslateX.toString() : "0")  + ","+
                    "\"maskTranslateY\":" + (animate.hasOwnProperty ("maskTranslateY") ? animate.maskTranslateY.toString() : "0") + ","+
                    "\"maskScaleX\":" + (animate.hasOwnProperty ("maskScale") ? (animate.maskScale[0]/100.0).toString() : "1")  + ","+
                    "\"maskScaleY\":" + (animate.hasOwnProperty ("maskScale") ? (animate.maskScale[1]/100.0).toString() : "1")  + ","+
                    "\"maskRotateX\":" + (animate.hasOwnProperty ("maskXRotation") ? toRadian(animate.maskXRotation).toString() : "0") + ","+
                    "\"maskRotateY\":" + (animate.hasOwnProperty ("maskYRotation") ? toRadian(animate.maskYRotation).toString() : "0") + ","+
                    "\"maskRotateZ\":" + (animate.hasOwnProperty ("maskRotate") ? animate.maskRotate * Math.PI / 180 : "0")  + ","+
                    "\"maskAlpha\":" + (animate.hasOwnProperty ("maskOpacity") ? (animate.maskOpacity/100.0).toString() : "1")  + ","+
                    "\"blurRadius\":" + animate.gasblur[0].toString() + ","+
                    "\"blurWidthOffset\":" + animate.gasblur[1].toString() + ","+
                    "\"blurHeightOffset\":"+ animate.gasblur[2].toString() +
                "}";
}
function toRadian(angle) {
    return angle  * Math.PI / 180
}
function getOFGaussianBlurFromLayer(layer) {
    if (layer == null || layer.effect == undefined || layer.effect.property("ADBE Gaussian Blur 2") == null) {
        return [0,1,1]
    }
    var gaussianBlurEffect = layer.effect.property("ADBE Gaussian Blur 2")
    var blurValue = gaussianBlurEffect.property("ADBE Gaussian Blur 2-0001").value
    var blurDirection = gaussianBlurEffect.property("ADBE Gaussian Blur 2-0002").value
    return toOFGaussianBlur(blurValue, blurDirection)
}
function toOFGaussianBlur(blurValue, blurDirection) {
    var widthOffset = Math.min(Math.max(3*blurValue/50.0, 1), 5.0)
    var heightOffset = Math.min(Math.max(3*blurValue/50.0, 1), 5.0)
    if (blurDirection == 1) {
        // 水平和垂直
    } else if (blurDirection == 2) {
        // 水平
        heightOffset = 1
    } else {
        // 垂直
        widthOffset = 1
    }
    return [Math.min(Math.max(blurValue/10.0, 0), 6.0) , widthOffset, heightOffset]
}
// ------------------------------------------- uinifo -------------------------------------------
function uiinfo() {
//~     var audioCount = uiinfo_music.length
//~     var audioJson = uiinfo_music.join (",");
//~     var videoCount = uiinfo_video.length
//~     var videoJson = uiinfo_video.join (","); 
    var audioCount = 0
    var audioJson = "";
    for (var ii = 0; ii < uiinfo_music.length; ii++) {
        if (audioJson.indexOf(uiinfo_music[ii])<0) {
            audioJson += uiinfo_music[ii] + ","
            audioCount++;
        }
    }
    if (audioJson.length > 0) {
        audioJson = audioJson.substr(0,audioJson.length-1)
    }

    var inputFilesCount = 0;
    var inputJson = "" ;
    var videoCount = 0
    var videoJson = "";
    var mergedVideoJson = "{}";
    if (needMergeVideo()) {//合并方案
        mergedVideoJson = "{\"url\":\""+resMergedVideoPath+"\",\"videoConfig\":"+getMergedVideoRect()+"}"
    } else {
        for (var ii = 0; ii < uiinfo_video.length; ii++) {
            if (videoJson.indexOf(uiinfo_video[ii])<0) {
                videoJson += "\""+uiinfo_video[ii].filePath + "\","
                videoCount++;
            }
        }
        if (videoJson.length > 0) {
            videoJson = videoJson.substr(0,videoJson.length-1)
        }
    }

    return "{"+
                "\"actorList\": [],"+
                "\"internalMemory\": 0,"+
                "\"limitCount\": 0,"+
                "\"musicConfig\": {"+
                                "\"count\": "+audioCount.toString()+","+
                                "\"musics\": ["+audioJson+"]"+
                                "},"+
                "\"videoConfig\": {"+
                                "\"count\": "+videoCount.toString()+","+
                                "\"videos\": ["+videoJson+"]"+","+
                                "\"mergedVideo\": "+mergedVideoJson+
                                "},"+
                "\"rotate\": 0,"+
                "\"textEditable\": false,"+
                "\"textFilterParams\": \"100:100\","+
                "\"thumbImage\": \"\","+
                "\"width\": 0.2"+
                "}";
 
}