﻿#include "utils.jsx"

function mov2webm(movPath,w,h) {
    if (movPath.indexOf(".mov")>0) {
        var webmPath = movPath.replace(".mov",".webm")
        var rootPath = webmPath.substr (0, webmPath.lastIndexOf("/"));
        var tempPath = rootPath + "/temp_webm.out"
         //ffmpeg
         system.callSystem("ffmpeg -i \""+movPath+"\" -f rawvideo -c:v rawvideo -an -vf scale="+w+":"+h+" -pix_fmt yuva420p \""+tempPath+"\"");
        //webms
         var encoder = platformSpecificPath(rootDirectory() + "/webmTool/alpha_encoder.exe")
         var vpxenc = platformSpecificPath(rootDirectory() + "/webmTool/vpxenc.exe")
         system.callSystem(encoder + " -w "+w+" -h "+h+" -i \""+tempPath+"\" -o \""+webmPath+"\" -b \""+vpxenc+"\" -useAlpha 1 --target-bitrate=256 --fps=30000/1200")
         var tempFile = new File(tempPath)
         if (tempFile.exists) {
            tempFile.remove()
         }
        var webmFile = new File(webmPath)
        if (webmFile.exists) {
           (new File(movPath)).remove();
           return webmPath;
        }
        throw  "webm fail";
    } else {
        throw  "only mov";
    }
}