﻿#include "utils.jsx"
#include "lua_resource.jsx"
#include "effect_json.jsx"
#include "svga.jsx"
#include "webm.jsx"

//-------------------------------------------------------------------------------------- main -------------------------------------------
var resMergedVideoPath = "res/mergedVideo.mp4"
var ExportType = {
    text: 4,
    video: 3,
    svga: 1,
    other: -1,
}
var path = app.project.file.fsName.toString().replace(".aep","") + "_of";
resetFolderIfNeed(path);
inputFiles = []
uiinfo_music = []
uiinfo_video = []
confirmMerge= undefined;
main()

function main() {
    for (var i = 1; i <= app.project.items.length; i++) {
        item = app.project.item(i)
        if (!(item instanceof CompItem) || item.numLayers <= 0) {
            continue
        }
        duration = item.duration
        frameRate = item.frameRate
        workAreaStart = item.workAreaStart
        workAreaDuration = item.workAreaDuration
        width = item.width
        height = item.height
        inputFiles = []
        uiinfo_music = []
        uiinfo_video = []
        
        var layers = splitLayers(item)
        var maskLayers = layers[0]
        var maskAllLayers = layers[1]
        var backgroundLayers = layers[2]
        var svgaLayers = layers[3]
        var otherLayers = layers[4]
        
        var filterJsons = []    
        var duplicatedLayerName = checkIfLayerNameDuplicated(otherLayers)
        if (duplicatedLayerName) {
            alert ("图层\"" + duplicatedLayerName + "\"名称重复", "导出失败")
            return
        }
        // background
        if (backgroundLayers.length > 0) {
            var pathInfo = saveBackgroundVideo (workAreaStart, workAreaDuration, backgroundLayers, path)
        }
        // mask all layer
        var maskAllPathInfo
        if (maskAllLayers.length > 0) {
            maskAllPathInfo = saveMaskAllVideo (workAreaStart, workAreaDuration, maskAllLayers, path)
        }
        // mask
        var maskVideoPathInfos = []
        if (Object.keys(maskLayers) != "") {
            maskVideoPathInfos = saveMaskVideos (workAreaStart, workAreaDuration, maskLayers, path)
            for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
                var pathInfo = maskVideoPathInfos[filePathIndex]
            }
        }
        
        // svga
        if (Object.keys(svgaLayers) != "") {
            var svgaPathInfos = saveSVGAs (workAreaStart, workAreaDuration, svgaLayers, path)
            for (var filePathIndex = 0; filePathIndex < svgaPathInfos.length; filePathIndex++) {
                var pathInfo = svgaPathInfos[filePathIndex]
                var svgaLayersForExporting = pathInfo.layers
                var mask = findMaskForLayer(svgaLayersForExporting[0], maskAllLayers.length > 0, backgroundLayers.length > 0, maskAllPathInfo, maskVideoPathInfos)
                var filterJSON = svgaFilter (workAreaStart, workAreaDuration, pathInfo.maskdName, width, height, pathInfo.path, mask.maskType, mask.maskRes)
                filterJsons.push (filterJSON)
            }
        }
        // other layers
        for (var layerIndex = 0; layerIndex < otherLayers.length; layerIndex++) {
            var layer = otherLayers[layerIndex]
            var keyTimes = getAllKeyTimesInLayer (layer, workAreaStart)
            var mask = findMaskForLayer(layer, maskAllLayers.length > 0, backgroundLayers.length > 0,  maskAllPathInfo, maskVideoPathInfos)
            var textAnimations = []
            if (mask.maskType == ExportType.text) {
                var textLayer = mask.maskRes.layer
                var textKeyTimes = getAllKeyTimesInLayer (textLayer, workAreaStart)
                for (var textKeyTimeIndex = 0; textKeyTimeIndex < textKeyTimes.length; textKeyTimeIndex++ ) {
                    var textKeyTime = textKeyTimes[textKeyTimeIndex]
                    if (!keyTimes.contains(textKeyTime)) {
                        keyTimes.push(textKeyTime);
                    }
                }
                textAnimations = getAnimationFromLayer(textLayer, keyTimes)
            }
            var animations = getAnimationFromLayer(layer, keyTimes)
            var animationFileName = nameWithRight(layer.name);
            if (textAnimations.length > 0) {
                for (var textAniamtionIndex = 0; textAniamtionIndex < textAnimations.length; textAniamtionIndex++ ) {
                    var textAnimation = textAnimations[textAniamtionIndex]
                    var animation = animations[textAniamtionIndex]
                    animation.maskTranslateX = textAnimation.translateX
                    animation.maskTranslateY = textAnimation.translateY
                    animation.maskScale = textAnimation.scale
                    animation.maskRotate = textAnimation.rotation
                    animation.maskOpacity = textAnimation.opacity
                    animation.maskXRotation = textAnimation.hasOwnProperty ("xRotation") ? textAnimation.xRotation : 0
                    animation.maskYRotation = textAnimation.hasOwnProperty ("yRotation") ? textAnimation.yRotation : 0
                    animation.maskZRotation = textAnimation.hasOwnProperty ("zRotation") ? textAnimation.zRotation : 0
                    animations[textAniamtionIndex] = animation
                }
            }
            // find mask video index
            
            
            // filter
            var filterJSON = oneFilter(path, animationFileName, layer, mask.maskType, mask.maskRes)
            filterJsons.push (filterJSON)
            
            // animation
            saveAnimations(animations, path, animationFileName)
        }

        //合并视频
        mergeVideoWithFFMPEG(path);
        //ofeffect
        var f = new File(path + "/effect"+i.toString()+".ofeffect");
        f.open ("we", "TEXT", "");
        f.encoding = "UTF-8"
        f.write (effectHeader(filterJsons.length, duration))
        f.write (filterJsons.join (","))
        f.write(effectFooter())
        f.close();
    }
    var f = new File(path + "/uiinfo.conf");
    f.open ("we", "TEXT", "");
    f.encoding = "UTF-8"
    f.write (uiinfo())
    f.close();
    copyLuaResources(path)
    alert("导出成功："+path);
}
//-------------------------------------------------------------------------------------- function -------------------------------------------
function needMergeVideo() {
    if (confirmMerge == undefined) {
       confirmMerge =confirm("检测到可使用合并方案优化合成速度，是否使用？");
    }
    if (!confirmMerge) {
        return false;
    }
    var hasAudio = false;
    var sameWH = true;
    var w = 0;
    var h = 0;
    for (var ii = 0; ii < uiinfo_video.length; ii++) {
        if (uiinfo_video[ii].audioEnable) {
            hasAudio = true;
        }
        if (sameWH) {
            if (w > 0) {
                if (w != uiinfo_video[ii].width || h != uiinfo_video[ii].height) {
                    sameWH = false;
                }
            } else {
                w = uiinfo_video[ii].width;
                h = uiinfo_video[ii].height;
            }
        }
    }
    var needMerge = (!hasAudio && sameWH && uiinfo_video.length>1 && uiinfo_video.length<=4 );
    return needMerge;
}
function getMergedVideoRect() {
    var s = {};
    s.count = uiinfo_video.length;
    s.rect = [];
    var w = uiinfo_video[0].width;
    var h = uiinfo_video[0].height;
    for (var ii = 0; ii < uiinfo_video.length; ii++) {
        var rect = rectWithIndex(ii, uiinfo_video.length)
        var r =  {
                        x: rect.x*w,
                        y: rect.y*h,
                        width: rect.width*w,
                        height: rect.height*h,
                    }
        s.rect.push(r);
    }

    return JSON.stringify(s)
}
function rectWithIndex(i, count) {
    var defineRects= [
        [{x:0, y:0, width:1, height:1}],
        [{x:0, y:0, width:1, height:1},{x:1, y:0, width:1, height:1}],
        [{x:0, y:0, width:1, height:1},{x:1, y:0, width:1, height:1},{x:0, y:1, width:1, height:1}],
        [{x:0, y:0, width:1, height:1},{x:1, y:0, width:1, height:1},{x:0, y:1, width:1, height:1},{x:1, y:1, width:1, height:1}]
//~         [{x:0, y:0, width:1, height:1},{x:1, y:0, width:1, height:1},{x:2, y:0, width:1, height:1},{x:0, y:1, width:1, height:1},{x:1, y:1, width:1, height:1}],
//~         [{x:0, y:0, width:1, height:1},{x:1, y:0, width:1, height:1},{x:2, y:0, width:1, height:1},{x:0, y:1, width:1, height:1},{x:1, y:1, width:1, height:1},{x:2, y:1, width:1, height:1}]
    ]
    var rect = defineRects[count-1][i]; 
    return rect
}
function padWithCount(count) {
    var definePads= [
        {w:1, h:1},
        {w:2, h:1},
        {w:2, h:2},
        {w:2, h:2}
//~         {w:2, h:2},
//~         {w:3, h:2}
    ]
    var pad= definePads[count - 1]; 
    return pad
}
function mergeVideoWithFFMPEG(root) {
    var inputMP4 = "";
    var complexStr = "";
    var outMp4 = root + "/" + resMergedVideoPath;
    var alias = ["a","b","c","d","e","f","g","h","i","j"]
    var padIntensity = padWithCount(uiinfo_video.length)
    
    for (var ii = 0; ii < uiinfo_video.length; ii++) {
        inputMP4 += " -i \"" + root + "/" + uiinfo_video[ii].filePath+"\"";
        complexStr += "["+ii.toString()+":v]";
        if (ii==0) {
            complexStr += "pad=iw*"+padIntensity.w+":ih*"+padIntensity.h;
        } else {
            var rect = rectWithIndex(ii, uiinfo_video.length)
            complexStr += "overlay=w*"+rect.x+":h*"+rect.y;
        }
        if (ii<uiinfo_video.length-1) {
            complexStr += "["+alias[ii]+"];["+alias[ii]+"]";
        }
    }
    if (needMergeVideo()) {//合并方案
        
        //合并视频的码率，防止拉大
        var totalRate = 0;
        for (var ii = 0; ii < uiinfo_video.length; ii++) {
            var b = readBitrate(root + "/" + uiinfo_video[ii].filePath)
            totalRate += b;
        }
        
        var order = "ffmpeg "+inputMP4;
        order += " -bf 0 ";
        order += " -x264-params crf=25:bframes=0"
        order += " -maxrate "+totalRate.toString()+"k -bufsize "+totalRate.toString()+"k "
        order += "-filter_complex \""+complexStr+"\" \"" + outMp4+"\""
        system.callSystem(order)
        for (var ii = 0; ii < uiinfo_video.length; ii++) {
            var s = new File(root  + "/"+ uiinfo_video[ii].filePath);
            if (s.exists) {
                s.remove();
            }
        }
    } 
}

function checkIfLayerNameDuplicated(layers) {
    var uniqueNames = []
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var layer = layers[layerIndex]
        if (uniqueNames.contains(layer.name)) {
            return layer.name
        } else {
            uniqueNames.push (layer.name)
        }
    }
    return false
}
function findMaskForLayer(layer, hasMaskAll, hasBackground, maskAllPathInfo, maskVideoPathInfos) {
    var maskRes = ""
    var maskType = ExportType.svga
    if (hasMaskAll) { 
        maskType = maskAllPathInfo.resType
        if (maskAllPathInfo.resType == ExportType.svga) {
            maskRes = maskAllPathInfo.path
        } else if (maskAllPathInfo.resType == ExportType.text) {
            maskRes = maskAllPathInfo.properties
        } else {
            maskRes = (hasBackground ? 1 : 0) + 1
        }   
    } else {
        for (var filePathIndex = 0; filePathIndex < maskVideoPathInfos.length; filePathIndex++) {
            var pathInfo = maskVideoPathInfos[filePathIndex]
            var maskdNames = pathInfo.maskdName.split ("_")
            if (maskdNames.contains (layer.name)) {
                maskType = pathInfo.resType
                if (maskType == ExportType.svga) {
                    maskRes = pathInfo.path
                } else if (pathInfo.resType == ExportType.text) {
                    maskRes = pathInfo.properties
                } else {
                    maskRes = (hasBackground ? 1 : 0) + filePathIndex + 1
                }
                break
            }
        }
    }
    
    // 检查轨道遮罩是否有指定
    if (layer.trackMatteType == TrackMatteType.ALPHA) {
        
    }
    return {maskType: maskType, maskRes: maskRes}
}
function splitLayers(compItem) {
    if (!(compItem instanceof CompItem)) {
        return [{}, [], [], {}, []]
    }
    var maskLayers = {}
    var maskAllLayers = []
    var backgroundLayers = []
    var svgaLayers = {}
    var otherLayers = []
    for (var layerIndex = 1; layerIndex <= compItem.numLayers; layerIndex++) {
        var layer = compItem.layer(layerIndex)
        if ((!layer.enabled && !layer.audioActive) || layer instanceof CameraLayer) {
            continue
        }
        if (isMaskLayer (layer)) {
            var maskLayersForALayer = maskLayers[getMaskdLayerName(layer)]
            if (maskLayersForALayer == undefined) {
                maskLayersForALayer = []
            }
            maskLayersForALayer.push (layer)
            maskLayers[getMaskdLayerName(layer)] = maskLayersForALayer
        }
        else if (isMaskAllLayer(layer)) {
            maskAllLayers.push (layer)
        }
        else if (isBackgroundLayer(layer)) {
            backgroundLayers.push (layer)
        }
        else if (isSVGALayer(layer)) {
            var svgaForLayers = svgaLayers[getOriginName(layer)]
            if (svgaForLayers == undefined) {
                svgaForLayers = []
            }
            svgaForLayers.push (layer)
            svgaLayers[getOriginName(layer)] = svgaForLayers
        }
        else {
            otherLayers.push (layer)
        }
    }
    return [maskLayers, maskAllLayers, backgroundLayers, svgaLayers, otherLayers.reverse()]
}
function isMaskLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("_mask") > 0 && !isMaskAllLayer(layer)
}
function isBackgroundLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name=="background"
}
function isMaskAllLayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.indexOf("maskall") != -1
}
function isSVGALayer(layer) {
    if (layer == undefined || layer == null) return false
    return layer.name.split ("_").pop().indexOf ("SVGA") != -1
}
function getMaskdLayerName(layer) {
    if (!isMaskLayer(layer)) {
        return ""
    }
    return layer.name.slice(0, layer.name.indexOf("_mask"))
}
function getMaskdAllLayerName(layer) {
    if (!isMaskAllLayer(layer)) {
        return ""
    }
    return "maskall"
}

function getOriginName(layer) {
    var nameComponents = layer.name.split ("_")
    nameComponents.pop()
    return nameComponents.join ("_")
}
function getBackgroundLayerName(layer) {
    if (!isBackgroundLayer(layer)) {
        return ""
    }
    
    return "background"
}
function getExportType(layer) {
    var exportType = layer.name.split ("_").pop()
    if (exportType.indexOf ("Video") != -1) {
        return ExportType.video
    } else if (exportType.indexOf ("SVGA") != -1) {
        return ExportType.svga
    }  else if (exportType.indexOf ("TEXT") != -1) {
        return ExportType.text
    } else if (isBackgroundLayer (layer) || isMaskAllLayer (layer) || isMaskLayer (layer)) {
        return ExportType.video
    } else {
        return ExportType.other
    }
}
function saveSVGAs(beginTime, duration, svgaLayers, basePath) {
    var svgaPaths = []
    for (var svgaName in svgaLayers) {
        var svgaLayersForExporting = svgaLayers[svgaName]
        var fileName = svgaName
        var filePathInfo = saveSVGAFromLayers (svgaLayersForExporting, basePath + "/res", fileName)
        var filePath = filePathInfo.filePath
        var extension = filePathInfo.extension
        fileName = nameWithRight(fileName)
        var resName = filePath.slice (filePath.indexOf ("res/"), filePath.length)
        svgaPaths.push ({path:resName, fileName: fileName, layers: svgaLayersForExporting})
    }
    return svgaPaths
}
function saveMaskVideos(beginTime, duration, maskLayers, basePath) {
    var videoPaths = []
    for (var maskdLayerName in maskLayers) {
        var maskLayersForALayer = maskLayers[maskdLayerName]
        var exportType = getExportType(maskLayersForALayer[0])
        if (exportType == ExportType.svga) {
            maskLayersForALayer = removeBackgroundMaskLayer(maskLayersForALayer)
        }
        var pathInfo = saveResourceForLayers(beginTime, duration, maskLayersForALayer, basePath, nameWithRight(maskLayersForALayer[0].containingComp.name) +guid()+ "_mask")
        pathInfo.maskdName = maskdLayerName
        videoPaths.push(pathInfo)
    }
    return videoPaths
}
function saveBackgroundVideo(beginTime, duration, backgroundLayers, basePath) {
    return saveResourceForLayers(beginTime, duration, backgroundLayers, basePath, nameWithRight(backgroundLayers[0].containingComp.name) + "_background")
}
function saveMaskAllVideo(beginTime, duration, maskAllLayers, basePath) {
    var exportType = getExportType(maskAllLayers[0])
    if (exportType == ExportType.svga) {
        maskAllLayers = removeBackgroundMaskLayer(maskAllLayers)
    }
    return saveResourceForLayers(beginTime, duration, maskAllLayers, basePath, nameWithRight(maskAllLayers[0].containingComp.name) + "_maskall")
}
function removeBackgroundMaskLayer(maskLayers) {
    var backgroundMaskLayer
    for (var layerIndex = 0; layerIndex < maskLayers.length; layerIndex++) {
        var alayer = maskLayers[layerIndex]
         if (alayer instanceof AVLayer &&
         alayer.mask.numProperties == 0 &&
         alayer.source instanceof FootageItem &&
         alayer.source.mainSource instanceof SolidSource &&
         alayer.source.mainSource.color.equalsTo([1,1,1])) {
             backgroundMaskLayer = alayer
             break
         }
    }
    if (backgroundMaskLayer != undefined) {
        maskLayers.remove(backgroundMaskLayer)
    }
    return maskLayers
}
function saveResourceForLayers(beginTime, duration, layers, basePath, fileName) {
    var filePathInfo
    var resName
    var exportType = getExportType(layers[0])
    var properties = ""
    if (exportType == ExportType.video) {
        filePathInfo = saveVideoFromLayers (layers, basePath + "/res", fileName, true)
        var filePath = filePathInfo.filePath
        resName = filePath.slice (filePath.indexOf ("res/"), filePath.length)
    } else if (exportType == ExportType.svga) {
        filePathInfo = saveSVGAFromLayers (layers, basePath + "/res", fileName)
        var filePath = filePathInfo.filePath
        resName = filePath.slice (filePath.indexOf ("res/"), filePath.length)
    } else if (exportType == ExportType.text) {
        properties = saveTextMaskFromLayers(layers)
    }
    if (exportType == ExportType.video) {
        var foundIndex = -1;
        for (var ii = 0; ii < uiinfo_video.length; ii ++) {
            if (uiinfo_video[ii].filePath == resName) {
                foundIndex = ii;
            }
        }
        if (foundIndex<0) {
            var videoInfo = {
                "beginTime":(parseInt((beginTime*1000))).toString(),
                "endTime":(parseInt((beginTime+duration)*1000)).toString(),
                "filePath":resName,
                "audioEnable":false
                };
            var size = readSize(basePath+"/"+resName);
            if (size.width > 0) {
                videoInfo.width = size.width;
                videoInfo.height = size.height;
            }
            uiinfo_video.push(videoInfo)
        }
    }
    return {path:resName, fileName: fileName, resType: exportType, properties:properties}
}

function saveTextMaskFromLayers(layers) {
    var properties = ""
    var layer = layers[0]
    var text = layer.sourceText.value.text.replace(/[\r\n]/g, "\\n") .replace(/[]/g, "\\n")
    var textFontSize = Math.round(layer.sourceText.value.fontSize)
    var textFont = layer.sourceText.value.fontFamily
    var textFontLocation = layer.sourceText.value.fontLocation
    var vertical = false
    var textBlod = false
    var textAlign = 0
    if (textFontLocation.length > 0) {
        var ttf = new File(textFontLocation)
        if (ttf.exists) {
            var copyPath = path + "/res/" + textFont + ".ttf"
            ttf.copy (copyPath)
        }
        textFont = "res/" + textFont + ".ttf"
    }
    if (layer.sourceText.value.fauxBold) {
        textBlod = "true";
    }
    //判断是否竖向排列
    var sourceRect = layer.sourceRectAtTime(0.0, true)
    if (sourceRect.height > sourceRect.width) {
        vertical = "true"
    }
    //对齐方式
    var just = layer.sourceText.value.justification
    switch (just) {
        case ParagraphJustification.CENTER_JUSTIFY:
            textAlign = 2;
            break;
        case ParagraphJustification.LEFT_JUSTIFY:
            textAlign = 0;
            break;
        case ParagraphJustification.RIGHT_JUSTIFY:
            textAlign = 1;
            break;
        default:
            textAlign = 2;
            break;
    }
    properties = {
        text: text,
        font: textFont,
        fontSize: textFontSize,
        vertical: vertical,
        bold: textBlod,
        align: textAlign,
        layer: layer
        }
    return properties
}
//---------------------------------------------------------------------- export layer --------------------------------------

function saveSVGAFromLayers(layers, path, fileName) {
    if (layers.length == 0) {
        return ""
    }
    var containingComp = layers[0].containingComp
    var originLayerEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        alayer.enabled = false
    }
    var imageFileNames = []
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var alayer = layers[layerIndex]
        alayer.enabled = true
        imageFileNames.push(alayer.index.toString())
    }
//~     saveImageFromLayersSeperatly(layers, path + "/temp", imageFileNames)
    var svgaResourceFolderPath = path + "/" + fileName + "_svga"
    var resourceDiretoryPath = startConvert(svgaResourceFolderPath)
    saveImageFromLayersSeperatly(layers, svgaResourceFolderPath, imageFileNames)
    var svgaFilePath = path + "/" + fileName + ".svga"
    zipFolder (resourceDiretoryPath, svgaFilePath)
    removeFolder (resourceDiretoryPath)
    
   var y2aObj = svgaToY2A (svgaFilePath, svgaFilePath.replace (".svga", ".y2a"))
    var a2mFilePath = y2aObj.a2mFilePath
    var y2aFolderPath = y2aObj.y2aFolderPath
//~     var specFilePath = svgaResourceFolderPath + "/movie.spec"
    
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
    }
    return {filePath: a2mFilePath, extension:"a2m", folderPath: y2aFolderPath}
}

function saveVideoFromLayers(layers, path, fileName,allIFrame) {
    var mp4Path
    if (layers.length == 1 && layers[0].source != undefined && layers[0].source.file != null) {
        var f = layers[0].source.file.displayName.substr (0, layers[0].source.file.displayName.indexOf ("."))
        var extension = layers[0].source.file.displayName.replace(f,"")
        var copyPath =  path + "/" +  fileName+""+extension;
        layers[0].source.file.copy (copyPath)
        
        if (extension == ".mp4") {
            mp4Path = copyPath
            var tmpPath = path + "/" +  fileName+"_new"+extension;
            transformVideoWithFFMPEG(copyPath, tmpPath, layers[0].containingComp.width, layers[0].containingComp.height,allIFrame)
            var oldFile = new File(mp4Path)
            if (oldFile.exists) {
                oldFile.remove()
            }
            var newFile = new File(tmpPath)
            newFile.rename(mp4Path)
        } else if (extension == ".avi"){
            mp4Path = copyPath.replace (".avi", ".mp4")
            transformVideoWithFFMPEG(copyPath, mp4Path, layers[0].containingComp.width, layers[0].containingComp.height,allIFrame)
            var aviFile = new File(path)
            if (aviFile.exists) {
                aviFile.remove()
            }
        } else {
            //create new video
            var tempFilePath = path + "/temp.avi"
            var path = exportLayers(layers, tempFilePath, -1)
            mp4Path = path.replace ("temp.avi", fileName + ".mp4")
            transformVideoWithFFMPEG(path, mp4Path, -1, -1,allIFrame)
            var aviFile = new File(path)
            if (aviFile.exists) {
                aviFile.remove()
            }
        }
    } else {
        //create new video
        var tempFilePath = path + "/temp.avi"
        var path = exportLayers(layers, tempFilePath, -1)
        mp4Path = path.replace ("temp.avi", fileName + ".mp4")
        transformVideoWithFFMPEG(path, mp4Path, -1, -1,allIFrame)
        var aviFile = new File(path)
        if (aviFile.exists) {
            aviFile.remove()
        }
    }
    return {filePath: mp4Path, extension:"mp4"}
}

function transformVideoWithFFMPEG(from, to, w, h, allIFrame) {
    var args = "-c:v libx264 -preset medium -strict -2 -pix_fmt yuv420p"
    args += " -bf 0 " //干掉B帧
    //args += " -vf fps=fps=20 "//设置帧率为20
    args += " -x264-params crf=25:bframes=0"
    var b = readBitrate(from)
    if (b > 1000) {
        b = 1000
    }
    if (b < 100) {
        b = 100
    }
    args += " -maxrate "+b.toString()+"k -bufsize "+b.toString()+"k "

    if (w > 0 && h > 0) {
        args += " -s "+w+"x"+h
        
        if (w%2 == 1 || h%2 == 1) {
            throw  "合成模块高宽需要偶数";
        }
        if (!(w%16 == 0 && h%16 == 0)) {
            throw  "合成模块高宽需要16的倍数";
        }
    }
//~     if (allIFrame) {
//~         args += " -g 1 "
//~     }
    system.callSystem("ffmpeg -i \""+from+"\" "+args+" \""+to + "\"")
}

function readBitrate(path) {
    var s = system.callSystem("ffmpeg -i \""+path+"\" ")
     var index1 = s.indexOf("bitrate:") + 8;
     var index2 = s.indexOf("kb/s") - index1;
     var b = s.substr(index1, index2).replace(/(^\s*)|(\s*$)/g, "")
     return b
}

function readSize(path) {
var aaads = new File(path);    
    
    var s = system.callSystem("ffmpeg -i \""+path+"\" ")
     var index1 = s.indexOf("yuv420p, ") + 9;
     var index2 = 7;
     var size = s.substr(index1, index2).replace(/(^\s*)|(\s*$)/g, "")
     var sizes = size.split("x")
     if (sizes.length > 1) {
        return {width:sizes[0],height:sizes[1]}
     } else {
        return {width:0,height:0}
     }
}

function saveImageFromLayers(layers, path, fileName) {
    var containingComp = layers[0].containingComp
    var originDuration = containingComp.workAreaDuration
    containingComp.workAreaDuration = containingComp.frameDuration
    var filePathWithFileName = path + "/" + fileName + "[#####].png"
    exportLayers(layers, filePathWithFileName, 14)
    containingComp.workAreaDuration = originDuration
    
    var opacities = []
    var scales = []
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var layer = layers[layerIndex]
        
        var opacity = layer.transform.opacity.valueAtTime(layer.inPoint, false)
        layer.transform.opacity.setValueAtTime(containingComp.workAreaStart, 100)
        var originScale = layer.transform.scale.valueAtTime(layer.inPoint, false)
        layer.transform.scale.setValueAtTime(containingComp.workAreaStart, [100,100,100])
        
        opacities.push(opacity)
        scales.push(originScale)
    }
    
    var frameIndex = (containingComp.workAreaStart*containingComp.frameRate) .toString()
    var fullFrameIndex = ""
    for (var i = 0; i < (5-frameIndex.length); i++) {
        fullFrameIndex += "0"
    }
    fullFrameIndex += frameIndex
    var imageFile = new File(path + "/" + fileName + fullFrameIndex + ".png")
    var newName = path + "/" + fileName + ".png"
    imageFile.rename (newName)
    
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var layer = layers[layerIndex]
        layer.transform.opacity.setValueAtTime(containingComp.workAreaStart, opacities[layerIndex])
        layer.transform.scale.setValueAtTime(containingComp.workAreaStart, scales[layerIndex])
    }

    return newName
}

function saveImageFromLayersSeperatly(layers, path, fileNames) {
    var containingComp = layers[0].containingComp
    var originDuration = containingComp.workAreaDuration
    var originStart = containingComp.workAreaStart
    containingComp.workAreaDuration = containingComp.frameDuration * 2
    var filePaths = []
    var folder = new Folder(path)
    if (!folder.exists) {
        folder.create()
    }
    for (var layerIndex = 0; layerIndex < layers.length; layerIndex++) {
        var layer = layers[layerIndex]
        var originColor
        if (layer instanceof AVLayer && layer.source instanceof FootageItem && layer.source.mainSource instanceof SolidSource) {
            originColor = layer.source.mainSource.color
//~             if (originColor.equalsTo([1, 1, 1])) {
//~                 continue
//~             }
            var color = []
            for (var colorIndex = 0; colorIndex < layer.source.mainSource.color.length; colorIndex++) {
                color.push(1-layer.source.mainSource.color[colorIndex])
            }
            layer.source.mainSource.color = color
        }
        
        var fileName = fileNames[layerIndex]
        containingComp.workAreaStart = (layer.inPoint > 0 ? layer.inPoint : 0)
        
        var opacity = layer.transform.opacity.valueAtTime(layer.inPoint, false)
        layer.transform.opacity.setValueAtTime(containingComp.workAreaStart, 100)
        var originScale = layer.transform.scale.valueAtTime(layer.inPoint, false)
        layer.transform.scale.setValueAtTime(containingComp.workAreaStart, [100,100,100])
        
        var filePathWithFileName = path + "/" + fileName + "[#####].png"
        exportLayers([layer], filePathWithFileName, 14)
        var frameIndex = Math.round((containingComp.workAreaStart*containingComp.frameRate)) .toString()
        var fullFrameIndex = ""
        for (var i = 0; i < (5-frameIndex.length); i++) {
            fullFrameIndex += "0"
        }
        fullFrameIndex += frameIndex
        var imageFile = new File(path + "/" + fileName + fullFrameIndex + ".png")
        var newName = path + "/" + fileName + ".png"
        imageFile.rename (newName)
        filePaths.push(newName)
        if (layer instanceof AVLayer && layer.source instanceof FootageItem && layer.source.mainSource instanceof SolidSource) {
            layer.source.mainSource.color = originColor
        }
        layer.transform.opacity.setValueAtTime(containingComp.workAreaStart, opacity)
        layer.transform.scale.setValueAtTime(containingComp.workAreaStart, originScale)
    }
    containingComp.workAreaStart = originStart
    containingComp.workAreaDuration = originDuration
    
    
    return filePaths
}

function exportLayers(layers, filePathWithFileName, usingTemplateIndex) {
    if (layers.length == 0) {
        return ""
    }
    var containingComp = layers[0].containingComp
    var originLayerEnabled = new Object()
    var originLayerAudioEnabled = new Object()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        originLayerEnabled[layerIndex] = alayer.enabled
        originLayerAudioEnabled[layerIndex] = alayer.audioEnabled
        if (layers.contains(alayer)) {
            alayer.enabled = true
        } else {
            alayer.enabled = false
            alayer.audioEnabled = false
        }
    }
    var renderQueue = app.project.renderQueue
    renderQueue.items.add(containingComp)
    var renderItem = app.project.renderQueue.item(app.project.renderQueue.numItems)
    var outputModule = renderItem.outputModule(1)
    if (usingTemplateIndex >= 0) {
        outputModule.applyTemplate(outputModule.templates[usingTemplateIndex])
    }
    outputModule.file = new File(filePathWithFileName)
    renderQueue.render()
    renderItem.remove()
    for (var layerIndex = 1; layerIndex <= containingComp.numLayers; layerIndex++) {
        var alayer = containingComp.layer(layerIndex)
        alayer.enabled = originLayerEnabled[layerIndex]
        alayer.audioEnabled = originLayerAudioEnabled[layerIndex]
    }
    return filePathWithFileName
}

//------------------------------------------------------------------------ Filter ------------------------------------------
function svgaToY2A(svgaFilePath, y2aFilePath) {
    var y2aToolPSPath = platformSpecificPath(rootDirectory() + "/Y2ATool/Y2ATool.exe")
    var svgaPSPath = platformSpecificPath(svgaFilePath)
    var y2aPSPath = platformSpecificPath(y2aFilePath)
    system.callSystem("\"" + y2aToolPSPath + "\" --y2aExOptimalEfficiency " + "\"" +svgaPSPath + "\" \"" + y2aPSPath + "\" png \"pingo -s9\"")
//~     system.callSystem("\"" + y2aToolPSPath + "\" --y2aExCheetah " + "\"" +svgaPSPath + "\" \"" + y2aPSPath + "\" png \"pingo -s9\"")
    var folderFilePath = y2aPSPath.replace (".y2a", "_y2a")
    var a2mFilePath
    unzipFile(y2aPSPath, folderFilePath)
    var folder = new Folder(folderFilePath)
    if  (folder.exists) {
        var files = folder.getFiles ()
        for (var i in files) {
            if (files[i] instanceof File && files[i].fsName.indexOf (".a2m")) {
                a2mFilePath = files[i].fsName
                break
            }
        }
    }
//~     removeFile (svgaPSPath)
    removeFile (y2aPSPath)
    return {a2mFilePath: independantPath(a2mFilePath), y2aFolderPath: independantPath(folderFilePath)}
}
function svgaFilter(startTime, duration, description, width, height, svgaPath, maskType, maskRes) {
    return "{"+
                    "\"beginTime\":"+(startTime<0 ? 0 : startTime).toString()+","+
                    "\"endTime\":"+(parseInt((startTime+duration)*1000)).toString()+","+
                    "\"type\":\"CustomLuaFilter\","+
                    "\"uuid\":\"{"+guid()+"}\","+
                    "\"isFreeze\":false,"+
                    "\"duration\":"+(parseInt(duration*1000)).toString()+","+
                    "\"description\":\""+description +"\","+
                    "\"paramf\":{"+
                                        "\"Width\":"+width.toString()+","+
                                        "\"Height\":"+height.toString()+","+
                                        "\"ScaleX\": 1.0,"+
                                        "\"ScaleY\": 1.0,"+
                                        "\"TranslateX\": 0.0,"+
                                        "\"TranslateY\": 0.0,"+
                                        "\"RotateX\": 0.0,"+
                                        "\"RotateY\": 0.0,"+
                                        "\"RotateZ\": 0.0,"+
                                        "\"Alpha\": 1.0,"+
                                        "\"BlurRadius\": 0.0,"+
                                        "\"BlurWidthOffset\": 1.0,"+
                                        "\"BlurHeightOffset\": 1.0,"+
                                        "\"MaskScaleX\": 1.0,"+
                                        "\"MaskScaleY\": 1.0,"+
                                        "\"MaskTranslateX\": 0.0,"+
                                        "\"MaskTranslateY\": 0.0,"+
                                        "\"MaskRotateX\": 0.0,"+
                                        "\"MaskRotateY\": 0.0,"+
                                        "\"MaskRotateZ\": 0.0,"+
                                        "\"MaskAlpha\": 1.0"+
                                        "},"+
                    "\"parami\":{"+
                                        "\"VideoIndex\":0,"+
                                        "\"RenderType\":4,"+
                                        "\"FontSize\":0,"+
                                        "\"BlendMode\":0,"+
                                        "\"MaskRenderType\":" + maskType.toString() + ", "+
                                        "\"MaskVideoIndex\":" + (maskType == ExportType.video ? maskRes : "0") + 
                                        "},"+
                    "\"parambool\":{\"FontBold\":false,\"FontShadow\":false,\"AnimationDataChanged\":true},"+
                    "\"paramenum\":{},"+
                    "\"paramres\":{\"RenderObject\":{\"resType\":8,\"resName\":\""+svgaPath+"\"},"+
                                            "\"Music\":{\"resType\":8,\"resName\":\""+svgaPath+"\"},"+
                                            "\"MaskTexture\":{\"resType\":" + maskType.toString() + ",\"resName\":\"" + maskRes + "\"},"+
                                            "\"AnimationFile\":{\"resType\":2048,\"resName\":\"\"}},"+
                    "\"paramresarr\":{},"+
                    "\"paramcolor\":{\"FontColor\":[1,1,1,1]},"+
                    "\"paramstring\":{\"RenderText\":\"\",\"Font\":\"\"},"+
                    "\"ext_data\":{\"luaScriptName\":\"locus.oflua\"}"+
                    "}";
}