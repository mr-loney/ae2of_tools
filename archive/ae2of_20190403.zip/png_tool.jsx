﻿#include "utils.jsx"

function pngCompress(path) {
    if (path.length>0) {
         var encoder = platformSpecificPath(rootDirectory() + "/PngTool/pngquant.exe")
         system.callSystem(encoder + " \"" + path + "\" --quality 50 -f -o \""+path+"\"")
    }
}