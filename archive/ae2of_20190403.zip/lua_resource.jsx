﻿#include "json2.jsx"
#include "utils.jsx"

function copyLuaResources(destPath) {
    var jsPath = (new File($.fileName)).fsName.replace("\\lua_resource.jsx","")
    var srcPath = jsPath.path

    var config = getAssets()
    try {
        var resources = [{"name":"locus","file":"locus.oflua","sucess":false}, 
                                    {"name":"music","file":"music.oflua","sucess":false}]
        var obj = JSON.parse(config)
        for (var cateIndex = 0; cateIndex < obj.data.length; cateIndex++) {
            for (var itemIndex = 0; itemIndex < obj.data[cateIndex].icons.length; itemIndex++) {
                for (var r = 0 ; r < resources.length; r++) {
                    if (obj.data[cateIndex].icons[itemIndex].name == resources[r].name && resources[r].sucess == false) {
                        var file = resources[r].file
                        var outFilePath = jsPath + "/tmp.zip"
                        var f = new File(outFilePath)
                        if (f.exists) {
                            f.remove ()
                        }

                        downloadResource(obj.data[cateIndex].icons[itemIndex].url,  outFilePath)
                        var unzipFolder = outFilePath.replace(".zip","_folder")
                        unzipFile(outFilePath,unzipFolder)
                        var luaFile = new File(unzipFolder + "/"+file )
                        luaFile.copy (destPath + "/" + file )
                        resources[r].sucess = true
                        
                        //clear cache
                        var zipFile = new File(outFilePath)
                        if (zipFile.exists) {
                            zipFile.close()
                            zipFile.remove()
                        }
                        var zipedFolder = new Folder(unzipFolder)
                        if (zipedFolder.exists) {
                            var files = zipedFolder.getFiles ()
                            for (var i in files) {
                                if (files[i] instanceof File) {
                                    files[i].remove()
                                } else if (files[i] instanceof Folder) {
                                    var subFiles = files[i].getFiles ()
                                    for (var j in subFiles) {
                                        if (subFiles[j] instanceof File) {
                                            subFiles[j].remove()
                                        }
                                    }
                                    files[i].remove()
                                }
                            }
                            zipedFolder.remove()
                        }
                    }
                }
//~                 if (obj.data[cateIndex].icons[itemIndex].name == "locus" && locusOK == false) {
//~                     
//~                     var outFilePath = jsPath + "/tmp.zip"
//~                     var f = new File(outFilePath)
//~                     if (f.exists) {
//~                         f.remove ()
//~                     }

//~                     downloadResource(obj.data[cateIndex].icons[itemIndex].url,  outFilePath)
//~                     var unzipFolder = outFilePath.replace(".zip","_folder")
//~                     unzipFile(outFilePath,unzipFolder)
//~                     var luaFile = new File(unzipFolder + "/locus.oflua")
//~                     luaFile.copy (destPath + "/" + locus.oflua)
//~                 }
            }
        }
    } catch(ex) {
        var resources = ["locus.oflua", "music.oflua"]
        for (var resourceIndex = 0;  resourceIndex < resources.length; resourceIndex++) {
            var resource = resources[resourceIndex]
            var resourceFile = new File(srcPath + "/" + resource)
            resourceFile.copy (destPath + "/" + resource)
        }
    }
}

function getAssets(){
    var jsPath = (new File($.fileName)).fsName.replace("\\lua_resource.jsx","")
    var outFilePath = jsPath + "/tmp.json"
    var f = new File(outFilePath)
    if (f.exists) {
        f.remove ()
    }

    downloadResource("http://ovotest.yy.com/asset/common?channel=3fd0c8b91d&version=1.0.0&os=1",  outFilePath)

    var outFile= new File(outFilePath)
    if (!outFile.exists) {
        return ""
    } else {
        outFile.open ("r", "TEXT", "")
        var jsonString = outFile.read()
        outFile.close()
        outFile.remove()
        return jsonString
    }
}

function downloadResource(url, dst) {
    var jsPath = (new File($.fileName)).fsName.replace("\\lua_resource.jsx","")
    
    var vbsFile = jsPath + "/getAssets.vbs"
    system.callSystem("cscript "+vbsFile+" \""+url+"\" "+dst+"")
}